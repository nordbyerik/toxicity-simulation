import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from pathlib import Path

def calculate_stats(data):
    """Calculate statistics from toxicity data."""
    data['toxicity'] = pd.to_numeric(data['toxicity'], errors='coerce').fillna(0)
    toxicity_values = data[data['toxicity'] > 0]['toxicity']
    total_posts = len(data)
    posts_with_toxicity = len(toxicity_values)
    
    return {
        'avgToxicity': toxicity_values.mean(),
        'medianToxicity': toxicity_values.median(),
        'percentWithToxicity': (posts_with_toxicity / total_posts) * 100,
        'totalPosts': total_posts,
        'postsWithToxicity': posts_with_toxicity
    }

def categorize_user_type(toxicity):
    """Categorize user based on toxicity level."""
    if toxicity < 0.72:
        return "Occasional"
    elif toxicity > 0.98:
        return "Serial"
    else:
        return "Moderate"

def calculate_user_type_stats(data):
    """Calculate statistics grouped by user type."""
    # Add user type classification
    data['user_type'] = data['author_toxicity'].apply(categorize_user_type)
    
    user_type_stats = {}
    for user_type in ['Occasional', 'Moderate', 'Serial']:
        user_data = data[data['user_type'] == user_type]
        if not user_data.empty:
            toxic_posts = len(user_data[user_data['toxicity'] > 0])
            total_posts = len(user_data)
            user_type_stats[user_type] = {
                'avgToxicity': user_data['toxicity'].mean(),
                'medianToxicity': user_data['toxicity'].median(),
                'percentWithToxicity': (toxic_posts / total_posts) * 100,
                'totalPosts': total_posts,
                'postsWithToxicity': toxic_posts,
            }
    return user_type_stats

def aggregate_ban_type_stats(processed_data_dir, stat_type="ban_type"):
    """Aggregate statistics for each ban type and user type."""
    processed_data_path = Path(processed_data_dir)
    ban_stats = {}
    user_type_stats = {}
    
    if stat_type == "ban_type":
        part = -5
        title = "Ban Type"
    elif stat_type == "strictness":
        part = -4
        title = "Strictness"
    elif stat_type == "misses":
        part = -3
        title = "Misses"
        
    # Walk through all directories
    for path in processed_data_path.glob("**/all_events.csv"):
        # Get ban type from path
        ban_type = path.parts[part]  # Assuming structure like "Full_Ban/2/2/all_events.csv"
        
        try:
            data = pd.read_csv(path)
            
            # Calculate regular stats
            stats = calculate_stats(data)
            if ban_type not in ban_stats:
                ban_stats[ban_type] = []
            ban_stats[ban_type].append(stats)
            
            # Calculate user type stats
            user_stats = calculate_user_type_stats(data)
            if ban_type not in user_type_stats:
                user_type_stats[ban_type] = {
                    'Occasional': [],
                    'Moderate': [],
                    'Serial': []
                }
            
            for user_type, type_stats in user_stats.items():
                user_type_stats[ban_type][user_type].append(type_stats)
                
        except Exception as e:
            print(f"Error processing {path}: {str(e)}")
            continue
    
    # Calculate averages for each ban type
    aggregated_stats = {
        'by_ban_type': {},
        'by_user_type': {}
    }
    
    # Aggregate ban type stats
    for ban_type, stats_list in ban_stats.items():
        print(f"Ban type: {ban_type}")
        print(f"Number of stats: {len(stats_list)}")
        if stats_list:
            # Debug print the values before mean calculation
            print(f"avgToxicity values: {[s['avgToxicity'] for s in stats_list]}")
            print(f"medianToxicity values: {[s['medianToxicity'] for s in stats_list]}")
            aggregated_stats['by_ban_type'][ban_type] = {
                'avgToxicity': np.mean([s['avgToxicity'] for s in stats_list]),
                'medianToxicity': np.mean([s['medianToxicity'] for s in stats_list]),
                'percentWithToxicity': np.mean([s['percentWithToxicity'] for s in stats_list]),
                'totalPosts': np.mean([s['totalPosts'] for s in stats_list]),
                'postsWithToxicity': np.mean([s['postsWithToxicity'] for s in stats_list]),
                'numRuns': len(stats_list)
            }
    
    # Aggregate user type stats
    for ban_type, user_types in user_type_stats.items():
        print(f"\nUser stats for ban type: {ban_type}")
        aggregated_stats['by_user_type'][ban_type] = {}
        for user_type, stats_list in user_types.items():
            print(f"User type: {user_type}")
            print(f"Number of stats: {len(stats_list)}")
            if stats_list:
                print(f"avgToxicity values: {[s['avgToxicity'] for s in stats_list]}")
                aggregated_stats['by_user_type'][ban_type][user_type] = {
                    'avgToxicity': np.mean([s['avgToxicity'] for s in stats_list]),
                    'medianToxicity': np.mean([s['medianToxicity'] for s in stats_list]),
                    'percentWithToxicity': np.mean([s['percentWithToxicity'] for s in stats_list]),
                    'totalPosts': np.mean([s['totalPosts'] for s in stats_list]),
                    'postsWithToxicity': np.mean([s['postsWithToxicity'] for s in stats_list]),
                    'numRuns': len(stats_list)
                }
    
    return aggregated_stats

def create_toxicity_over_time_plot(processed_data_dir, stat_type="ban_type"):
    """Create line plots showing toxicity trends over time for different ban types."""
    ban_time_series = {}
    
    if stat_type == "ban_type":
        part = -5
        title = "Ban Type"
    elif stat_type == "strictness":
        part = -4
        title = "Strictness"
    elif stat_type == "misses":
        part = -3
        title = "Misses"
    for path in Path(processed_data_dir).glob("**/all_events.csv"):
        ban_type = path.parts[part]
        data = pd.read_csv(path)
        data['toxicity'] = pd.to_numeric(data['toxicity'], errors='coerce').fillna(0)

        # Group by timestamp and count posts with toxicity > 0
        time_data = data.groupby('timestamp').agg({
            'toxicity': lambda x: (x > 0).sum()  # Count posts with any toxicity
        }).reset_index()
        time_data.columns = ['timestamp', 'toxic_posts']  # Rename column for clarity
        
        if ban_type not in ban_time_series:
            ban_time_series[ban_type] = []
        ban_time_series[ban_type].append(time_data)

    # Create plot
    fig = go.Figure()
    
    for ban_type, series_list in ban_time_series.items():
        # Average the toxic post counts across all runs of same type
        avg_series = pd.concat(series_list).groupby('timestamp')['toxic_posts'].mean()
        fig.add_trace(go.Scatter(
            x=avg_series.index,
            y=avg_series.values,
            name=ban_type,
            mode='lines'
        ))
    
    fig.update_layout(
        title=f"Toxic Posts Over Time by {title}",
        xaxis_title="Timestamp",
        yaxis_title="Number of Toxic Posts",
        height=600,
        width=1000
    )
    
    return fig


def create_ban_type_plots(processed_data_dir, stat_type):
    """Create toxicity analysis plots for different ban types."""
    # Colors for different metrics
    metric_colors = {
        'avgToxicity': '#3b82f6',  # Blue
        'percentWithToxicity': '#22c55e',  # Green
        'totalPosts': '#f97316'  # Orange
    }
    
    if stat_type == "ban_type":
        title = "Ban Type"
    elif stat_type == "strictness":
        title = "Strictness"
    elif stat_type == "misses":
        title = "Misses"
        
    # Get stats
    stats = aggregate_ban_type_stats(processed_data_dir, stat_type)
    
    # Create DataFrame for ban_type stats
    ban_type_df = pd.DataFrame.from_dict(stats['by_ban_type'], orient='index')
    
    # Create figure with subplots
    fig = make_subplots(
        rows=3, cols=1,
        subplot_titles=(
            f'Average Toxicity by {title}',
            f'Percent Posts with Toxicity by {title}',
            f'Average Posts per Run by {title}'
        ),
        vertical_spacing=0.15
    )
    
    # Add traces for each metric
    fig.add_trace(
        go.Bar(
            x=ban_type_df.index,
            y=ban_type_df['avgToxicity'],
            text=[f"{x:.2f}" for x in ban_type_df['avgToxicity']],
            textposition='auto',
            marker_color=metric_colors['avgToxicity'],
            showlegend=False,
        ),
        row=1, col=1
    )
    
    fig.add_trace(
        go.Bar(
            x=ban_type_df.index,
            y=ban_type_df['percentWithToxicity'],
            text=[f"{x:.2f}%" for x in ban_type_df['percentWithToxicity']],
            textposition='auto',
            marker_color=metric_colors['percentWithToxicity'],
            showlegend=False
        ),
        row=2, col=1
    )
    
    fig.add_trace(
        go.Bar(
            x=ban_type_df.index,
            y=ban_type_df['totalPosts'],
            text=[f"{x:.0f}" for x in ban_type_df['totalPosts']],
            textposition='auto',
            marker_color=metric_colors['totalPosts'],
            showlegend=False
        ),
        row=3, col=1
    )
    
    # Update layout
    fig.update_layout(
        height=1000,
        width=800,  # Reduced width since we only have one column now
        title_text=f"{title} Analysis",
        title_font_size=20,
        title_x=0.5,
        plot_bgcolor='white',
        paper_bgcolor='white',
        showlegend=False
    )
    
    # Update axes
    for i in range(1, 4):
        fig.update_xaxes(tickfont_size=12, tickfont_color='#6b7280', row=i, col=1)
        fig.update_yaxes(tickfont_size=12, tickfont_color='#6b7280', row=i, col=1)
            
    return fig


def create_user_toxicity_distribution_plot(processed_data_dir, stat_type):
    """Create violin plots showing distribution of user toxicity levels."""
    user_toxicity = {}

    if stat_type == "ban_type":
        part = -5
        title = "Ban Type"
    elif stat_type == "strictness":
        part = -4
        title = "Strictness"
    elif stat_type == "misses":
        part = -3
        title = "Misses"
    
    for path in Path(processed_data_dir).glob("**/all_events.csv"):
        ban_type = path.parts[part]
        data = pd.read_csv(path)
        
        # Group by author and calculate mean toxicity
        author_toxicity = data['toxicity']
        
        if ban_type not in user_toxicity:
            user_toxicity[ban_type] = []
        user_toxicity[ban_type].extend(author_toxicity.fillna(0).tolist())
    
    fig = go.Figure()
    
    for ban_type, toxicity_values in user_toxicity.items():
        if (stat_type == "strictness") or (stat_type == "misses"):
            ban_type = f"0.{ban_type}"
        fig.add_trace(go.Box(
            y=toxicity_values,
            name=ban_type,
            boxmean='sd',
            
        ))
    
    fig.update_layout(
        title=f"Distribution of Post Toxicity by {title}",
        yaxis_title="Post Toxicity",
        height=600,
        width=800
    )
    
    return fig


def create_moderation_action_plot(processed_data_dir, stat_type):
    """Create stacked chart showing distribution of moderation actions."""
    action_counts = {}
    
    if stat_type == "ban_type":
        part = -5
    elif stat_type == "strictness":
        part = -4
    elif stat_type == "misses":
        part = -3
    
    for path in Path(processed_data_dir).glob("**/moderation_actions.csv"):
        ban_type = path.parts[part]
        data = pd.read_csv(path)
        
        # Count different types of actions
        action_dist = data['action_type'].value_counts()
        
        if ban_type not in action_counts:
            action_counts[ban_type] = []
        action_counts[ban_type].append(action_dist)
    
    # Average across runs
    avg_actions = {
        ban_type: pd.concat(counts).groupby(level=0).mean()
        for ban_type, counts in action_counts.items()
    }
    
    fig = go.Figure()
    
    for action in ['ban', 'warning', 'toxicity overload']:
        fig.add_trace(go.Bar(
            name=action,
            x=list(avg_actions.keys()),
            y=[stats.get(action, 0) for stats in avg_actions.values()],
        ))
    
    fig.update_layout(
        barmode='stack',
        title="Average Moderation Actions by Ban Type",
        xaxis_title="Ban Type",
        yaxis_title="Number of Actions",
        height=600,
        width=800
    )
    
    return fig


def create_platform_comparison_plot(processed_data_dir, stat_type):
    """Create heatmap comparing toxicity across platforms and ban types."""
    platform_stats = {}
    
    if stat_type == "ban_type":
        part = -5
    elif stat_type == "strictness":
        part = -4
    elif stat_type == "misses":
        part = -3
    
    for path in Path(processed_data_dir).glob("**/all_events.csv"):
        ban_type = path.parts[part]
        data = pd.read_csv(path)
        
        # Calculate average toxicity per platform
        platform_toxicity = (data.groupby('platform')['toxicity'].apply(lambda x: (x > 0).mean() * 100))
        
        if ban_type not in platform_stats:
            platform_stats[ban_type] = []
        platform_stats[ban_type].append(platform_toxicity)
    
    # Average across runs
    avg_platform_stats = {
        ban_type: pd.concat(stats).groupby(level=0).mean()
        for ban_type, stats in platform_stats.items()
    }
    
    # Create heatmap
    fig = go.Figure(data=go.Heatmap(
        z=[[stats[i] for i in range(1, 4)] for stats in avg_platform_stats.values()],
        x=['Platform 1', 'Platform 2', 'Platform 3'],
        y=list(avg_platform_stats.keys()),
        colorscale='RdBu_r'
    ))
    
    fig.update_layout(
        title="Average Toxicity by Platform and Ban Type",
        height=500,
        width=800
    )
    
    return fig


def create_migration_flow_diagrams(processed_data_dir, stat_type):
    """Create separate Sankey diagrams for each ban type showing user movement between platforms."""
    migration_counts = {}
    
    if stat_type == "ban_type":
        part = -5
    elif stat_type == "strictness":
        part = -4
    elif stat_type == "misses":
        part = -3
    
    # Collect data
    for path in Path(processed_data_dir).glob("**/platform_activity.csv"):
        ban_type = path.parts[part]
        data = pd.read_csv(path)
        
        # Sort by time period to track movements
        data = data.sort_values(['agent', 'time_period'])
        
        # Track platform transitions
        transitions = []
        for agent in data['agent'].unique():
            agent_data = data[data['agent'] == agent]
            agent_data = agent_data[agent_data['active']]  # Only look at active platforms
            
            # Get sequence of platforms
            platforms = agent_data.groupby('time_period')['platform_name'].apply(list)
            
            # Look at consecutive time periods
            for t1, t2 in zip(platforms.index[:-1], platforms.index[1:]):
                for p1 in platforms[t1]:
                    for p2 in platforms[t2]:
                        transitions.append((p1, p2))
        
        if ban_type not in migration_counts:
            migration_counts[ban_type] = []
        migration_counts[ban_type].append(pd.Series(transitions).value_counts())
    
    # Create separate figure for each ban type
    figures = {}
    for ban_type, counts_list in migration_counts.items():
        avg_counts = pd.concat(counts_list).groupby(level=0).mean()
        
        # Create nodes and links
        platforms = list(set([p for transition in avg_counts.index for p in transition]))
        platform_to_idx = {p: i for i, p in enumerate(platforms)}
        
        fig = go.Figure(data=[go.Sankey(
            node=dict(
                pad=15,
                thickness=20,
                line=dict(color="black", width=0.5),
                label=platforms,
                color="blue"
            ),
            link=dict(
                source=[platform_to_idx[src] for src, _ in avg_counts.index],
                target=[platform_to_idx[tgt] for _, tgt in avg_counts.index],
                value=avg_counts.values,
                color="rgba(0,0,255,0.2)"
            )
        )])
        
        fig.update_layout(
            title=f"User Migration Between Platforms - {ban_type}",
            font_size=10,
            height=600,
            width=800
        )
        
        figures[ban_type] = fig
    
    return figures



if __name__ == "__main__":
    # Create the full comparison plots
    fig_ban_type = create_ban_type_plots("./processed_data", "ban_type")
    # fig_toxicity_over_time = create_toxicity_over_time_plot("./processed_data", "ban_type")
    fig_user_toxicity = create_user_toxicity_distribution_plot("./processed_data", "ban_type")
    fig_platform = create_platform_comparison_plot("./processed_data", "ban_type")
    # fig_moderation_actions = create_moderation_action_plot("./processed_data", "ban_type")
    # migration_figs = create_migration_flow_diagrams("./processed_data", "ban_type")

    fig_ban_type.write_image("ban_type_analysis.png")  # or .jpg
    # fig_toxicity_over_time.write_image("ban_type_toxicity_over_time_analysis.png")
    fig_user_toxicity.write_image("ban_type_user_toxicity_distribution_analysis.png")
    fig_platform.write_image("ban_type_platform_comparison_percent.png")
    # fig_moderation_actions.write_image("ban_type_moderation_actions_analysis.png")



    fig_ban_type = create_ban_type_plots("./processed_data", "strictness")
    # fig_toxicity_over_time = create_toxicity_over_time_plot("./processed_data", "strictness")
    fig_user_toxicity = create_user_toxicity_distribution_plot("./processed_data", "strictness")
    fig_platform = create_platform_comparison_plot("./processed_data", "strictness")
    # fig_moderation_actions = create_moderation_action_plot("./processed_data", "strictness")
    # migration_figs = create_migration_flow_diagrams("./processed_data", "strictness")

    fig_ban_type.write_image("strictness_analysis.png")  # or .jpg
    # fig_toxicity_over_time.write_image("strictness_toxicity_over_time_analysis.png")
    fig_user_toxicity.write_image("strictness_user_toxicity_distribution_analysis.png")
    fig_platform.write_image("strictness_platform_comparison_percent.png")
    # fig_moderation_actions.write_image("strictness_moderation_actions_analysis.png")



    fig_ban_type = create_ban_type_plots("./processed_data", "misses")
    # fig_toxicity_over_time = create_toxicity_over_time_plot("./processed_data", "misses")
    fig_user_toxicity = create_user_toxicity_distribution_plot("./processed_data", "misses")
    fig_platform = create_platform_comparison_plot("./processed_data", "misses")
    # fig_moderation_actions = create_moderation_action_plot("./processed_data", "misses")
    # migration_figs = create_migration_flow_diagrams("./processed_data", "misses")

    fig_ban_type.write_image("misses_analysis.png")  # or .jpg
    # fig_toxicity_over_time.write_image("misses_toxicity_over_time_analysis.png")
    fig_user_toxicity.write_image("misses_user_toxicity_distribution_analysis.png")
    fig_platform.write_image("misses_platform_comparison_analysis.png")
    # fig_moderation_actions.write_image("misses_moderation_actions_analysis.png")