# file: config_parser.py
import xml.etree.ElementTree as ET
from pathlib import Path

class ConfigParser:
    @staticmethod
    def get_run_parameters(run_path):
        """Extract parameters from construct config file"""
        config_file = Path(run_path) / 'construct_gen.xml'
        if not config_file.exists():
            print(f"Config file not found in {run_path}")
            return {}
            
        try:
            tree = ET.parse(config_file)
            root = tree.getroot()
            
            params = {
                'run_id': Path(run_path).name
            }
            
            # Extract model parameters
            for model in root.findall('.//model'):
                name = model.get('name')
                if name and name.startswith('Toxic Model'):
                    platform_num = name.split()[-1]
                    model_params = {}
                    
                    for param in model.findall('.//param'):
                        param_name = param.get('name')
                        param_value = param.get('value')
                        if param_name and param_value:
                            model_params[param_name] = param_value
                    
                    params[f'platform_{platform_num}'] = model_params

            params['user_toxicity'] = ConfigParser.get_user_toxicity(root)

            return params
            
        except ET.ParseError as e:
            print(f"Error parsing XML file: {e}")
            return {'run_id': Path(run_path).name}
        except Exception as e:
            print(f"Unexpected error processing parameters: {e}")
            return {'run_id': Path(run_path).name}


    @staticmethod 
    def get_user_toxicity(root):
        """Extract user toxicity values from the toxic agent network"""
        try:
            # Find the toxic agent network
            toxic_network = root.find(".//network[@name='toxic agent network']")
            if toxic_network is None:
                return {}
                
            toxicity_values = {}
            # Get toxicity values from links
            for link in toxic_network.findall('.//link'):
                agent = link.get('src_index')
                agent = f'agent_{int(agent)+1}'
                value = link.get('value')
                if agent and value:
                    try:
                        toxicity_values[agent] = float(value)
                    except ValueError:
                        continue
                        
            return toxicity_values
            
        except Exception as e:
            print(f"Error extracting user toxicity: {e}")
            return {}


# file: event_processor.py
import json
import pandas as pd

class EventProcessor:
    @staticmethod
    def process_events_file(file_path, platform_id, params):
        """Process a platform's events JSON file"""
        try:
            with open(file_path) as f:
                data = json.load(f)
            
            platform_params = params.get(f'platform_{platform_id}', {})
            user_toxicity = params.get('user_toxicity', {})

            events = []
            
            for event in data['data']:
                event_data = {
                    'platform': platform_id,
                    'timestamp': event.get('created_at'),
                    'author': event.get('author_id'),
                    'author_toxicity': user_toxicity.get(event.get('author_id')),
                    'toxicity': None,
                    'knowledge': None
                }
                
                if 'entities' in event:
                    entities = event['entities']
                    if 'values' in entities:
                        for val in entities.get('values', []):
                            if 'toxicity' in val:
                                event_data['toxicity'] = val['toxicity']
                    
                    if 'indexes' in entities:
                        for idx in entities.get('indexes', []):
                            if 'knowledge' in idx:
                                event_data['knowledge'] = idx['knowledge']
                
                event_data.update({
                    f'platform_{k}': v 
                    for k, v in platform_params.items()
                })
                
                events.append(event_data)
                
            return pd.DataFrame(events)
            
        except Exception as e:
            print(f"Error processing events file {file_path}: {e}")
            return pd.DataFrame()

# file: output_processor.py
import xml.etree.ElementTree as ET
import pandas as pd
from pathlib import Path

class OutputProcessor:
    @staticmethod
    def process_output_xml(file_path, params):
        """Process the output XML file containing platform activity and moderation data"""
        try:
            tree = ET.parse(file_path)
            root = tree.getroot()
            
            # Sets to collect unique values
            unique_agents = set()
            unique_platforms = set()
            unique_timeperiods = set()
            active_combinations = set()  # To track which combinations are actually active
            moderation_actions = []
            
            run_id = params.get('run_id', Path(file_path).parent.name)
            
            user_toxicity = params.get('user_toxicity', {})
            
            # First pass: collect all unique values and active combinations
            for meta_network in root.findall('.//MetaNetwork'):
                time_period = meta_network.get('timePeriod')
                unique_timeperiods.add(time_period)
                
                for network in meta_network.findall('.//network'):
                    network_id = network.get('id', '')
                    
                    if network_id == 'agent activity on platforms':
                        for link in network.findall('.//link'):
                            target_model = link.get('target')
                            if target_model and target_model.startswith('Toxic Model'):
                                agent = link.get('source')
                                unique_agents.add(agent)
                                unique_platforms.add(target_model)
                                active_combinations.add((agent, target_model, time_period))
                                
                    elif network_id in ['ban network', 'warning network', 'toxicity overload network']:
                        for link in network.findall('.//link'):
                            target_model = link.get('target')
                            if target_model and target_model.startswith('Toxic Model'):
                                action_data = {
                                    'run_id': run_id,
                                    'agent': link.get('source'),
                                    'agent_toxicity': user_toxicity.get(link.get('source')),
                                    'platform_name': target_model,
                                    'action_type': network_id.replace(' network', ''),
                                    'value': link.get('value'),
                                    'time_period': time_period
                                }
                                moderation_actions.append(action_data)

            # Generate complete activity matrix
            platform_activities = []
            for time_period in unique_timeperiods:
                for agent in unique_agents:
                    for platform in unique_platforms:
                        platform_activities.append({
                            'run_id': run_id,
                            'agent': agent,
                            'agent_toxicity': user_toxicity.get(agent),
                            'platform_name': platform,
                            'time_period': time_period,
                            'active': (agent, platform, time_period) in active_combinations
                        })
            
            # Convert to dataframes
            platform_activities_df = pd.DataFrame(platform_activities)
            moderation_actions_df = pd.DataFrame(moderation_actions)
            
            # Convert numeric columns
            for df in [platform_activities_df, moderation_actions_df]:
                if not df.empty:
                    if 'time_period' in df.columns:
                        df['time_period'] = pd.to_numeric(df['time_period'], errors='coerce')
                    if 'value' in df.columns:
                        df['value'] = pd.to_numeric(df['value'], errors='coerce')
            
            return platform_activities_df, moderation_actions_df
            
        except Exception as e:
            print(f"Error processing output XML {file_path}: {e}")
            return pd.DataFrame(), pd.DataFrame()

# file: statistics.py
import json
from pathlib import Path

class StatisticsCalculator:
    @staticmethod
    def count_timesteps(run_dir, number_of_nets):
        """Count total number of timesteps in any platform's events"""
        try:
            max_timestep = 0
            run_path = Path(run_dir)
            
            for i in range(1, number_of_nets + 1):
                events_file = run_path / f'toxic_{i}.json'
                if events_file.exists():
                    with open(events_file) as f:
                        data = json.load(f)
                        if 'data' in data:
                            timestamps = [event.get('created_at', 0) for event in data['data']]
                            if timestamps:
                                max_timestep = max(max_timestep, max(timestamps))
            
            return max_timestep + 1
        except Exception as e:
            print(f"Error counting timesteps: {e}")
            return 0

    @staticmethod
    def count_users(run_dir, number_of_nets):
        """Count unique users across all platforms"""
        try:
            unique_users = set()
            run_path = Path(run_dir)
            
            for i in range(1, number_of_nets + 1):
                events_file = run_path / f'toxic_{i}.json'
                if events_file.exists():
                    with open(events_file) as f:
                        data = json.load(f)
                        if 'data' in data:
                            users = {event.get('author_id') for event in data['data'] if event.get('author_id')}
                            unique_users.update(users)
            
            return len(unique_users)
        except Exception as e:
            print(f"Error counting users: {e}")
            return 0

# file: main.py
import os
from pathlib import Path

class SimulationManager:
    def __init__(self, base_dir, output_dir, number_of_nets):
        self.base_dir = Path(base_dir)
        self.output_dir = Path(output_dir)
        self.number_of_nets = number_of_nets
        self.run_summaries = []

    def process_single_run(self, run_dir):
        """Process a single simulation run"""
        run_path = self.base_dir / run_dir

        # Split the string by '_' and extract relevant parts
        parts = run_dir.split('_')
        
        # Get all numeric parts from the end
        numbers = []
        for part in reversed(parts):
            if part.isdigit():
                numbers.insert(0, part)
            else:
                break
        
        # Take only the numbers we want (skipping the 0s)
        # For "Warning_Full_Ban_0_2_0_2_9" or "Full_Ban_0_2_0_2_9"
        # we want 2, 2, 9
        relevant_numbers = [numbers[-4], numbers[-2], numbers[-1]]

        if int(relevant_numbers[2]) > 4:
            return
        
        # Get the base folder name by taking all non-numeric parts
        base_parts = []
        for part in parts:
            if not part.isdigit():
                base_parts.append(part)
        base_folder = '_'.join(base_parts)
        
        # Create the path by joining components
        output_path = base_folder
        for num in relevant_numbers:
            output_path = f"{output_path}/{num}"
        
        run_output_dir = self.output_dir / output_path
        run_output_dir.mkdir(parents=True, exist_ok=True)
        

        # Get configuration
        params = ConfigParser.get_run_parameters(run_path)
        
        # Process events

        all_events_df = pd.DataFrame()
        for i in range(1, self.number_of_nets + 1):
            events_file = run_path / f'toxic_{i}.json'
            if events_file.exists():
                events_df = EventProcessor.process_events_file(events_file, i, params)
                if not events_df.empty:
                    events_df.to_csv(run_output_dir / f'platform_{i}_events.csv', index=False)
                    all_events_df = pd.concat([all_events_df, events_df])
        
        if not all_events_df.empty:
            all_events_df.to_csv(run_output_dir / 'all_events.csv', index=False)

        # Process output
        output_file = run_path / 'my_ouput.xml'
        if output_file.exists():
            activity_df, moderation_df = OutputProcessor.process_output_xml(output_file, params)
            if not activity_df.empty:
                activity_df.to_csv(run_output_dir / 'platform_activity.csv', index=False)
            if not moderation_df.empty:
                moderation_df.to_csv(run_output_dir / 'moderation_actions.csv', index=False)

        # Calculate statistics
        stats = {
            'num_timesteps': StatisticsCalculator.count_timesteps(run_path, self.number_of_nets),
            'num_users': StatisticsCalculator.count_users(run_path, self.number_of_nets)
        }

        # Save run summary
        self._save_run_summary(run_dir, params, stats, run_output_dir)

    def process_all_runs(self):
        """Process all simulation runs"""
        for run_dir in os.listdir(self.base_dir):
            run_path = self.base_dir / run_dir
            if run_path.is_dir():
                print(f"Processing run {run_dir}")
                self.process_single_run(run_dir)

    def _save_run_summary(self, run_dir, params, stats, output_dir):
        """Save run summary and metadata"""
        summary = {
            'run_id': run_dir,
            'statistics': stats,
            'parameters': params
        }
        
        with open(output_dir / 'run_summary.json', 'w') as f:
            json.dump(summary, f, indent=2)
        
        self.run_summaries.append(summary)

if __name__ == "__main__":
    manager = SimulationManager(
        base_dir='./data',
        output_dir='./processed_data',
        number_of_nets=3
    )
    manager.process_all_runs()