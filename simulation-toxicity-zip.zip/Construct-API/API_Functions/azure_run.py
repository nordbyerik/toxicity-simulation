from azure.ai.ml import command
from azure.ai.ml.entities import AmlCompute, Environment
from azure.ai.ml import MLClient
from azure.identity import DefaultAzureCredential

def setup_compute(ml_client):
    # Create a low-priority compute cluster
    compute_name = "sim-cluster"
    
    compute_cluster = AmlCompute(
        name=compute_name,
        type="amlcompute",
        size="Standard_DS1_v2",  # 1 core VM - adjust based on simulation needs
        tier="low_priority",     # Cheaper VMs
        min_instances=0,
        max_instances=20,        # Adjust based on how many parallel sims you want
        idle_time_before_scale_down=120
    )
    
    ml_client.begin_create_or_update(compute_cluster).result()
    return compute_name

def create_cpp_environment(ml_client):
    # Create minimal environment for C++ builds
    env = Environment(
        name="cpp-build-env",
        image="ubuntu:20.04",
        conda_file={
            "name": "cpp-env",
            "channels": ["conda-forge"],
            "dependencies": [
                "make",
                "cmake",
                "gcc",
                "g++"
            ]
        }
    )
    ml_client.environments.create_or_update(env)
    return env.name

def submit_simulation_jobs(ml_client, compute_name, env_name, sim_configs):
    jobs = []
    
    for config in sim_configs:
        # Each config could be different parameters for your simulation
        job = command(
            code=".",  # Your source code directory
            command=f"""
                make clean_debug && 
                make && 
                cd Linux/Debug &&
                ./construct {config}
            """,
            environment=env_name,
            compute=compute_name,
            display_name=f"sim-run-{config}"
        )
        
        returned_job = ml_client.jobs.create_or_update(job)
        jobs.append(returned_job)
        print(f"Submitted simulation for config {config}: {returned_job.name}")
    
    return jobs

def main():
    # Connect to workspace
    ml_client = MLClient(
        DefaultAzureCredential(),
        subscription_id="3cd95cb4-5c6c-4b23-b93c-3e28b37066b3",
        resource_group_name="enordbyrg",
        workspace_name="enordbyml"
    )
    
    # Setup compute and environment
    compute_name = setup_compute(ml_client)
    env_name = create_cpp_environment(ml_client)
    
    # Define your simulation configurations
    sim_configs = [
        "construct_gen.xml"
        # Add more configurations as needed
    ]
    
    # Submit all jobs
    jobs = submit_simulation_jobs(ml_client, compute_name, env_name, sim_configs)
    
    # Optionally wait for and monitor jobs
    for job in jobs:
        ml_client.jobs.stream(job.name)


from azure.ai.ml import command
from azure.ai.ml.entities import ComputeConfiguration
from azure.ai.ml import MLClient
from azure.identity import DefaultAzureCredential

def submit_serverless_jobs(
    subscription_id: str,
    resource_group: str,
    workspace_name: str,
    versions: list
):
    # Connect to workspace
    ml_client = MLClient(
        DefaultAzureCredential(),
        subscription_id,
        resource_group,
        workspace_name
    )
    
    # Configure serverless compute
    serverless_compute = ComputeConfiguration(
        instance_type="serverless",
        runtime="python",  # or "r" or "tensorflow" depending on your needs
        max_run_duration_seconds=3600  # 1 hour max runtime
    )
    
    jobs = []
    for version in versions:
        # Create serverless job
        job = command(
            code=".",
            command=f"make clean_debug && make && cd Linux/Debug && ./construct {version}",
            environment="my-new-env",
            compute=serverless_compute,
            display_name=f"construct-build-{version}",
        )
        
        # Submit job
        returned_job = ml_client.jobs.create_or_update(job)
        jobs.append(returned_job)
        print(f"Submitted serverless job for version {version}: {returned_job.name}")
    
    return jobs

# Example usage
versions = ["construct_gen.xml"]  # your different versions/configurations
jobs = submit_serverless_jobs(
        subscription_id="3cd95cb4-5c6c-4b23-b93c-3e28b37066b3",
        resource_group="enordbyrg",
        workspace_name="enordbyml",
    versions=versions
)

# Monitor jobs if desired
for job in jobs:
    print(f"Job {job.name} status: {job.status}")
