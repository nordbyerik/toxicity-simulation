import subprocess
import argparse
from concurrent.futures import ProcessPoolExecutor
import os
from datetime import datetime
import json
import threading
import sys
def stream_output(process, sim_number):
    """Stream output from the process in real-time"""
    prefix = f"[Sim {sim_number}] "
    for line in process.stdout:
        sys.stdout.write(prefix + line)
        sys.stdout.flush()
    
    for line in process.stderr:
        sys.stderr.write(prefix + line)
        sys.stderr.flush()


def run_simulation(args):
    """
    Run a single instance of the simulation with given parameters
    """
    sim_number, executable_path, params = args

    # Create a unique output filename for this simulation
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"test/sim_{sim_number}_{timestamp}.out"
    
    # Construct the command
    cmd = [executable_path]
    params = [params]
    if params:
        cmd.extend(params)
    
    print("Running: ", cmd)
    # Run the simulation and capture output
    try:
        # Use Popen to get live output
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,  # Line buffered
            universal_newlines=True
        )
        
        # Create thread to handle output streaming
        output_thread = threading.Thread(target=stream_output, args=(process, sim_number))
        output_thread.daemon = True
        output_thread.start()
        
        # Wait for process to complete
        return_code = process.wait()
        output_thread.join()
        
        if return_code != 0:
            return {
                'sim_number': sim_number,
                'status': 'failed',
                'return_code': return_code
            }
        return {
            'sim_number': sim_number,
            'status': 'success',
            'return_code': return_code
        }
        
    except Exception as e:
        print(f"[Sim {sim_number}] Error: {str(e)}")
        return {
            'sim_number': sim_number,
            'status': 'failed',
            'error': str(e)
        }


def main():


    params = []
    for i in range(5):
        for strictness in [0.05, 0.2, 0.5]:
            for misses in [0.2, 0.4, 0.6]:
                strictness_string = str(strictness).replace(".", "_")
                misses_string = str(misses).replace(".", "_")
                params.append(f"Partial_Ban_{strictness_string}_{misses_string}_{i}.xml")

    for i in range(5):
        for strictness in [0.05, 0.2, 0.5]:
            for misses in [0.2, 0.4, 0.6]:
                strictness_string = str(strictness).replace(".", "_")
                misses_string = str(misses).replace(".", "_")
                params.append(f"Warning_Partial_Ban_{strictness_string}_{misses_string}_{i}.xml")
    


    for i in range(5):
        for strictness in [0.05, 0.2, 0.5]:
            for misses in [0.2, 0.4, 0.6]:
                strictness_string = str(strictness).replace(".", "_")
                misses_string = str(misses).replace(".", "_")
                params.append(f"Warning_Full_Ban_{strictness_string}_{misses_string}_{i}.xml")
    
    for i in range(5):
        for strictness in [0.05, 0.2, 0.5]:
            for misses in [0.2, 0.4, 0.6]:
                strictness_string = str(strictness).replace(".", "_")
                misses_string = str(misses).replace(".", "_")
                params.append(f"Full_Ban_{strictness_string}_{misses_string}_{i}.xml")
    
    num_runs = len(params)
    
    # Prepare arguments for each simulation run
    sim_args = [
        (i, "./construct", params[i])
        for i in range(num_runs)
    ]
    
    # Run simulations in parallel
    max_workers = os.cpu_count()
    print(f"Starting {num_runs} simulations using {max_workers} workers...")
    
    results = []
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        results = list(executor.map(run_simulation, sim_args))

    # Print summary
    successful = sum(1 for r in results if r['status'] == 'success')
    print(f"\nCompleted {successful}/{num_runs} simulations successfully")
    
    # Print any errors
    failed_runs = [r for r in results if r['status'] == 'failed']
    if failed_runs:
        print("\nFailed runs:")
        for run in failed_runs:
            print(f"Simulation {run['sim_number']} failed:")
            print(run['error'])

if __name__ == '__main__':
    main()