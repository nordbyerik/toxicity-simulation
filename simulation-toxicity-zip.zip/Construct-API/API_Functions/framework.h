#pragma once
#if defined WIN32 || defined _WIN32 || defined __CYGWIN__ || defined __MINGW32__
#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
// Windows Header Files
#include <windows.h>
#endif
