Here is all of the code which was used for either the simulation, parsing of data, visualization of results, or the creation of the website.

# Simulation Code
The main code which was updated for the simulation is in the include/Construct_Models folder. Specifically, the ToxicModeration, ToxicModel, and ToxicUser files are relevant. There were other files which were updated, but those were to clean up bugs in the Construct code, produce better logging, or make minor adjustments so they can be ignored for the most part.

If you want to run this, I'm happy to help get it running. It's pretty sensitive to the local environment you're using, so that may be a challenge. I'm on an M1 Mac, so the output from when I compile the code is in the API_Functions/Darwin/Debug folder. To compile the code yourself, you can navigate into the API_Functions folder and use the Makefile. 

The configuration for the simulations can be found as xml files in the API_Functions/Darwin/Debug folder. Since they're so large, it's unwieldy to write them by hand. So I have a python script (Python_Construct_Input_Builder/Erik_Input_Builder.py) which can be used to programatically generate the config files.

The runner is API_Functions/Darwin/Debug/run.py. It iterates through each of the xml config files in the API_Functions/Darwin/Debug folder and runs the simulation using those configs. It drops the output into the respective folder. FYI, it finds the number of cores on your machine and runs the simulations in parallel on all available cores. If you just want to run it with one config, you can navigate into the correct folder for your machine (i.e. API_Functions/Darwin/Debug), and run "./construct <config_file>"

For more thorough documentation, see the original README.md or the Construct User Manual.

# Website Code
The code for the website is in the toxicity-analysis folder. It's a pretty standard React app & is currently deployed using Vercel to https://toxicity-analysis.vercel.app/

# Data and Visualization Code
The output data and data visualization code is stored in the preprocessing folder. I left only one folder of the output data as an example because there were hundreds of them and each is relatively large.
- preprocessing/data contains the raw output. 
- preprocessing/processed_data contains the data after preprocessing.
- toxicity-preprocessing.py is the code used to preprocess the data.
- toxicity-graphing.py is the code used to generate the graphs. These graphs are moved to the website folder to be displayed.

