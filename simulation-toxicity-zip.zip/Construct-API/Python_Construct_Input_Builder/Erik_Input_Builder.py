from typing import List, Dict
import random
from bs4 import BeautifulSoup, element
from construct_input_builder import ConstructBuilder



class ConstructConfig:
    def __init__(self, 
                 num_agents: int = 2,
                 num_networks: int = 1,
                 time_steps: int = 500,
                 num_knowledge: int = 3,
                 num_toxic: int = 1,
                 time_period: float = 1.0,
                 main_rules: dict = None,
                 run_name: str = "Run1",
                 seed: int = 0):

        self.seed = seed
        self.num_agents = num_agents
        self.num_networks = num_networks
        self.time_steps = time_steps
        self.num_knowledge = num_knowledge
        self.num_toxic = num_toxic
        
        # Default activity parameters

        self.base_rates_high_activity = {
            "post density": 0.08 * time_period,
            "read density": 20 * time_period, #TODO: I guess this is drawn from poisson?
            "repost probability": 0.03,
            "reply probability": 0.02,
            "quote probability": 0.01
        }

        self.base_rates_medium_activity = {
            "post density": 0.04 * time_period,
            "read density": 20 * time_period,
            "repost probability": 0.02,
            "reply probability": 0.02,
            "quote probability": 0.01
        }

        self.base_rates_low_activity = {
            "post density": 0.02 * time_period,
            "read density": 20 * time_period,
            "repost probability": 0.005,
            "reply probability": 0.01,
            "quote probability": 0.001
        }

        self.base_rates_very_low_activity = {
            "post density": 0.01 * time_period,
            "read density": 20 * time_period,
            "repost probability": 0.001,
            "reply probability": 0.002,
            "quote probability": 0.0001
        }
        # Creates exponentially decaying preferences for each network
        self.platform_preference_weights = [(num_agents*10)**(-i/10) for i in range(num_networks)]

        self.activity_weight = 3.14

        self.run_name = run_name

        self.network_rules = [
                main_rules,
                {
                    "network_name": "Network2",
                    "rule": "true",
                    "toxicity threshold": "0.05", #TODO: Make this a variable
                    "full ban": "true",
                    "partial ban": "false",
                    "warning": "false",
                    "remove content": "true",
                    "network ban threshold": "1",
                    "network warning threshold": "1",
                    "moderation miss probability": "0.2",
                    "partial ban length": "6"
                },
                        
                {
                    "network_name": "Network3",
                    "rule": "true",
                    "toxicity threshold": "1", #TODO: Make this a variable
                    "full ban": "false",
                    "partial ban": "false",
                    "warning": "false",
                    "remove content": "false",
                    "network ban threshold": "2",
                    "network warning threshold": "1",
                    "moderation miss probability": "0.5",
                    "partial ban length": "6"
                }
            ]


def create_activity_nodes(num_networks: int) -> List[str]:
    """Generate activity node names for all networks."""
    activities = ["post density", "read density", "repost probability", 
                 "reply probability", "quote probability"]
    nodes = []
    
    # Add Network1, Network2, etc. activities
    for i in range(num_networks):
        network_name = f"Network{i+1}"
        nodes.extend([f"{network_name} {activity}" for activity in activities])
    
    return nodes

def create_construct_xml(config: ConstructConfig, output_filename: str = "API_Functions/Darwin/Debug/construct_gen.xml"):
    construct = ConstructBuilder()

    # Add construct parameters
    construct.add_construct_parameter("verbose runtime", "false")
    construct.add_construct_parameter("verbose initalization", "false")
    construct.add_construct_parameter("seed", config.seed)
    construct.add_construct_parameter("custom library", "./libconstructAPI.dylib")

    # Add time nodeset
    time_ns = construct.add_nodeset("time")
    generator = construct.soup.new_tag('generator')
    generator.attrs['type'] = 'constant'
    count_param = construct.soup.new_tag('count')
    count_param.attrs['value'] = str(config.time_steps)
    generator.append(count_param)
    time_ns.append(generator)

    # Add agent nodeset
    agent_ns = construct.add_nodeset("agent")
    agent_attributes = {
        "can send knowledge": "true",
        "can send knowledge trust": "true",
        "can receive knowledge": "true",
        "can receive knowledge trust": "true",
        "agent trust resistance": ".9",
        "alter trust weight": ".1",
    }
    
    for i in range(config.num_agents):
        agent = construct.add_node(agent_ns, f"agent_{i}")
        construct.add_node_attribute(agent, agent_attributes)
        for network_index in range(config.num_networks):
            network_agent_attributes = {
                f"Network{network_index + 1} add follower density": "0.75",
                f"Network{network_index + 1} remove follower scale factor": "0.75",
                f"Network{network_index + 1} charisma": "0.5",
                f"Network{network_index + 1} auto follow": "true"
            }
            construct.add_node_attribute(agent, network_agent_attributes)
        


    # Add activity nodeset
    activity_ns = construct.add_nodeset("activity")
    activity_nodes = create_activity_nodes(config.num_networks)
    for activity in activity_nodes:
        construct.add_node(activity_ns, activity)

    # Add model nodeset
    model_ns = construct.add_nodeset("model")

    # Add Toxic Model 1 (changed from loop to match original XML)
    for network_index in range(config.num_networks):
        toxic_model = construct.add_node(model_ns, f"Toxic Model {network_index + 1}")
        construct.add_node_attribute(toxic_model, {
            "network name": f"Network{network_index + 1}",
            "moderated": "true",
            "ban threshold": config.network_rules[network_index]["network ban threshold"],
            "toxicity threshold": config.network_rules[network_index]["toxicity threshold"],
            "moderation threshold": ".01",
            "partial ban length": config.network_rules[network_index]["partial ban length"],
            "model name": f"Toxic Model {network_index + 1}",
            "interval time duration": "0.1",
            "maximum post inactivity": "24.0",
            "full ban": config.network_rules[network_index]["full ban"],
            "partial ban": config.network_rules[network_index]["partial ban"],
            "warning": config.network_rules[network_index]["warning"],
            "remove content": config.network_rules[network_index]["remove content"],
            "network ban threshold": config.network_rules[network_index]["network ban threshold"],
            "network warning threshold": config.network_rules[network_index]["network warning threshold"],
            "moderation miss probability": config.network_rules[network_index]["moderation miss probability"],
            "partial ban length": config.network_rules[network_index]["partial ban length"]
        })

    # Trust Model
    trust_model = construct.add_node(model_ns, "Toxic Trust Model")
    construct.add_node_attribute(trust_model, {
        "relax rate": "0.2"
    })

    # Add knowledge nodeset
    knowledge_ns = construct.add_nodeset("knowledge")
    for i in range(config.num_knowledge):
        node = construct.add_node(knowledge_ns, f"knowledge_{i}")
        if i == 2:  # Make knowledge_2 moderated (matching original XML)
            construct.add_node_attribute(node, {"moderated": "true"})

    # Add toxic nodeset
    toxic_ns = construct.add_nodeset("toxic")
    generator = construct.soup.new_tag('generator')
    generator.attrs['type'] = 'constant'
    count_param = construct.soup.new_tag('count')
    count_param.attrs['value'] = str(config.num_toxic)
    generator.append(count_param)
    toxic_ns.append(generator)

    # Add networks
    # Knowledge network - changed default to true and edge_type to bool
    net = construct.add_network(
        "knowledge network", "bool", "agent", "knowledge",
        src_rep="sparse", trg_rep="sparse", default_value="true"
    )
    generator = construct.soup.new_tag('generator')
    generator.attrs['type'] = 'random binary'
    density_param = construct.soup.new_tag('param')
    density_param.attrs['name'] = 'density'
    density_param.attrs['value'] = '0.3'
    generator.append(density_param)
    net.append(generator)

    net = construct.add_network(
        "platform switch probability network", "float", "agent", "model",
        src_rep="sparse", trg_rep="sparse", default_value="0.4"
    )


    platform_preference_weights_net = construct.add_network(
        "platform preference network", "float", "agent", "model",
        src_rep="sparse", trg_rep="sparse", default_value="1"
    )

    for src in range(config.num_agents):
        for trg, rate in enumerate(config.platform_preference_weights):
            construct.add_network_link(platform_preference_weights_net, str(src), str(trg), value=str(rate))


    # Activity networks
    activity_net = construct.add_network(
        "agent activity weights network", "float", "agent", "activity",
        src_rep="dense", trg_rep="dense", default_value="3.14"
    )

    # Add base rate network links matching the original XML structure
    all_base_rates = []
    for _ in range(config.num_networks):
        for rate in config.base_rates_high_activity.values():
            all_base_rates.append(rate)

    for src in range(int(config.num_agents * 0.05)):
        for trg, rate in enumerate(all_base_rates):
            construct.add_network_link(activity_net, str(src), str(trg), value=str(rate))

    # Add 20% of agents to medium activity base rate network
    all_base_rates = []
    for _ in range(config.num_networks):
        for rate in config.base_rates_medium_activity.values():
            all_base_rates.append(rate)

    complete_agents = int(config.num_agents * 0.05)

    for src in range(complete_agents, complete_agents + int(config.num_agents * 0.2)):
        for trg, rate in enumerate(all_base_rates):
            construct.add_network_link(activity_net, str(src), str(trg), value=str(rate))

    # Add 25% of agents to low activity base rate network
    all_base_rates = []
    for _ in range(config.num_networks):
        for rate in config.base_rates_low_activity.values():
            all_base_rates.append(rate)
    
    complete_agents = complete_agents + int(config.num_agents * 0.2)

    for src in range(complete_agents, complete_agents + int(config.num_agents * 0.25)):
        for trg, rate in enumerate(all_base_rates):
            construct.add_network_link(activity_net, str(src), str(trg), value=str(rate))
    
    # Add 50% of agents to very low activity base rate network
    all_base_rates = []
    for _ in range(config.num_networks):
        for rate in config.base_rates_very_low_activity.values():
            all_base_rates.append(rate)

    complete_agents = complete_agents + int(config.num_agents * 0.25)

    for src in range(complete_agents, config.num_agents):
        for trg, rate in enumerate(all_base_rates):
            construct.add_network_link(activity_net, str(src), str(trg), value=str(rate))


    # Base activity rate network
    base_rate_net = construct.add_network(
        "base activity rate network", "float", "agent", "activity",
        src_rep="dense", trg_rep="dense", default_value="0"
    )

    # Add 5% of agents to high activity base rate network
    all_base_rates = []
    for _ in range(config.num_networks):
        for rate in config.base_rates_high_activity.values():
            all_base_rates.append(rate)

    for src in range(int(config.num_agents * 0.05)):
        for trg, rate in enumerate(all_base_rates):
            construct.add_network_link(base_rate_net, str(src), str(trg), value=str(rate))

    # Add 20% of agents to medium activity base rate network
    all_base_rates = []
    for _ in range(config.num_networks):
        for rate in config.base_rates_medium_activity.values():
            all_base_rates.append(rate)

    complete_agents = int(config.num_agents * 0.05)

    for src in range(complete_agents, complete_agents + int(config.num_agents * 0.2)):
        for trg, rate in enumerate(all_base_rates):
            construct.add_network_link(base_rate_net, str(src), str(trg), value=str(rate))

    # Add 25% of agents to low activity base rate network
    all_base_rates = []
    for _ in range(config.num_networks):
        for rate in config.base_rates_low_activity.values():
            all_base_rates.append(rate)
    
    complete_agents = complete_agents + int(config.num_agents * 0.2)

    for src in range(complete_agents, complete_agents + int(config.num_agents * 0.25)):
        for trg, rate in enumerate(all_base_rates):
            construct.add_network_link(base_rate_net, str(src), str(trg), value=str(rate))
    
    # Add 50% of agents to very low activity base rate network
    all_base_rates = []
    for _ in range(config.num_networks):
        for rate in config.base_rates_very_low_activity.values():
            all_base_rates.append(rate)

    complete_agents = complete_agents + int(config.num_agents * 0.25)

    for src in range(complete_agents, config.num_agents):
        for trg, rate in enumerate(all_base_rates):
            construct.add_network_link(base_rate_net, str(src), str(trg), value=str(rate))

    # Toxic networks with random uniform generators
    for network_name in ["toxic susceptibility network"]:
        net = construct.add_network(
            network_name, "float", "agent", "toxic",
            src_rep="dense", trg_rep="dense", default_value="0.1"
        )
        generator = construct.soup.new_tag('generator')
        generator.attrs['type'] = 'random uniform'
        min_param = construct.soup.new_tag('param')
        min_param.attrs['name'] = 'min'
        min_param.attrs['value'] = '0.0'
        max_param = construct.soup.new_tag('param')
        max_param.attrs['name'] = 'max'
        max_param.attrs['value'] = '1.0'
        generator.append(min_param)
        generator.append(max_param)
        net.append(generator)

    toxic_agent_net = construct.add_network(
        "toxic agent network", "float", "agent", "toxic",
        src_rep="dense", trg_rep="dense", default_value="0.1"
    )
    for src in range(0, config.num_agents):
        construct.add_network_link(toxic_agent_net, str(src), str(0), value=str(random.random()))

    # Agent trust network with density parameter
    net = construct.add_network(
        "agent trust network", "float", "agent", "agent",
        src_rep="dense", trg_rep="sparse", default_value="0.3"
    )
    generator = construct.soup.new_tag('generator')
    generator.attrs['type'] = 'random uniform'
    density_param = construct.soup.new_tag('param')
    density_param.attrs['name'] = 'density'
    density_param.attrs['value'] = '0.3'
    min_param = construct.soup.new_tag('param')
    min_param.attrs['name'] = 'min'
    min_param.attrs['value'] = '0.0'
    max_param = construct.soup.new_tag('param')
    max_param.attrs['name'] = 'max'
    max_param.attrs['value'] = '1.0'
    generator.append(density_param)
    generator.append(min_param)
    generator.append(max_param)
    net.append(generator)

    # Knowledge trust network with updated generator values
    net = construct.add_network(
        "knowledge trust network", "float", "agent", "knowledge",
        src_rep="dense", trg_rep="dense", default_value="0.3"
    )
    generator = construct.soup.new_tag('generator')
    generator.attrs['type'] = 'random uniform'
    min_param = construct.soup.new_tag('param')
    min_param.attrs['name'] = 'min'
    min_param.attrs['value'] = '0.3'
    max_param = construct.soup.new_tag('param')
    max_param.attrs['name'] = 'max'
    max_param.attrs['value'] = '0.7'
    generator.append(min_param)
    generator.append(max_param)
    net.append(generator)


    # Agent activity across networks 


    # Based on platform preference weights
    for network_index in range(config.num_networks):
        default_value = "true" if network_index == 0 else "false"
        agent_active_time_net = construct.add_network(
            f"Network{network_index + 1}agent active time network", "bool", "agent", "time",
            src_rep="sparse", trg_rep="sparse", default_value="true"
        )

        #Get preference weights for this network
        preference_weight = config.platform_preference_weights[network_index]
        for src in range(0, config.num_agents):
            rand = random.random()
            if rand > preference_weight:
                for trg in range(config.time_steps):
                    construct.add_network_link(agent_active_time_net, str(src), str(trg), value="false")


    # Knowledge trust transactive memory network
    construct.add_network(
        "knowledge trust transactive memory network", "float", "agent", "agent",
        slice_nodeset="knowledge", src_rep="dense", trg_rep="dense", slc_rep="sparse",
        default_value="0.5"
    )

    # Knowledge trust resistance network
    construct.add_network(
        "knowledge trust resistance network", "float", "agent", "knowledge",
        src_rep="dense", trg_rep="dense", default_value="0.75"
    )

    # Network follower networks
    for network_index in range(config.num_networks):
        net = construct.add_network(
            f"Network{network_index + 1} follower network", "bool", "agent", "agent",
            src_rep="dense", trg_rep="dense", default_value="0"
        )
        generator = construct.soup.new_tag('generator')
        generator.attrs['type'] = 'random binary'
        density_param = construct.soup.new_tag('param')
        density_param.attrs['name'] = 'density'
        density_param.attrs['value'] = '0.75'
        generator.append(density_param)
        net.append(generator)
    
    for network_index in range(config.num_networks):
        construct.add_model(f"Toxic Model {network_index + 1}", {
            "model name": f"Toxic Model {network_index + 1}",
            "network name": f"Network{network_index + 1}",  # Note: Changed to match original XML
            "interval time duration": "0.1",
            "maximum post inactivity": "24.0",
            "toxicity threshold": config.network_rules[network_index]["toxicity threshold"], #TODO: Make this a variable
            "full ban": config.network_rules[network_index]["full ban"],
            "partial ban": config.network_rules[network_index]["partial ban"],
            "warning": config.network_rules[network_index]["warning"],
            "remove content": config.network_rules[network_index]["remove content"],
            "network ban threshold": config.network_rules[network_index]["network ban threshold"],
            "network warning threshold": config.network_rules[network_index]["network warning threshold"],
            "moderation miss probability": config.network_rules[network_index]["moderation miss probability"],
            "partial ban length": config.network_rules[network_index]["partial ban length"]
    })
    
    construct.add_model("Toxic Moderation Model", {
        "interval time duration": "1.0",
        "maximum post inactivity": "10.0",
        "toxicity threshold": "0.75",
        "moderation style": "0"
    })
    
    construct.add_model("Toxic Trust Model", {
        "relax rate": "0.2"
    })

    # Ban network
    construct.add_network(
        "ban network", "unsigned int", "agent", "model",
        src_rep="dense", trg_rep="dense", default_value="0"
    )

    # Partial ban network
    construct.add_network(
        "partial ban network", "unsigned int", "agent", "model",
        src_rep="dense", trg_rep="dense", default_value="0"
    )

    # Warning network
    construct.add_network(
        "warning network", "unsigned int", "agent", "model",
        src_rep="dense", trg_rep="dense", default_value="0"
    )

    # Toxicity overload network
    construct.add_network(
        "toxicity overload network", "int", "agent", "model",
        src_rep="dense", trg_rep="dense", default_value="-1"
    )

    # Toxicity overload tracker network
    construct.add_network(
        "toxicity overload tracker", "bool", "agent", "model",
        src_rep="dense", trg_rep="dense", default_value="false"
    )

    # Agent activity on platforms network
    construct.add_network(
        "agent activity on platforms", "bool", "agent", "model",
        src_rep="dense", trg_rep="dense", default_value="false"
    )

    # Add outputs
    construct.add_output("dynetml", {
        "network names": "toxicity overload tracker, platform preference network, base activity rate network, ban network, warning network, toxicity overload network, toxic agent network, agent activity on platforms",
        "output file": f"{config.run_name}/my_ouput.xml",
        "timeperiods": "0,10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200,210,220,230,240,250,260,270,280,290,300,310,320,330,340,350,360"
    })

    for network_index in range(config.num_networks):
        # Add media event outputs
        construct.add_output("media events", {
            "model name": f"Toxic Model {network_index + 1}",
            "output file": f"{config.run_name}/toxic_{network_index + 1}.json",
            "start time": "2024-09-11T00:00:00.000Z",
            "time conversion to seconds": "360.0"
        })
    

    # Write the XML file
    construct.write(output_filename)

    # Create a copy of the XML file in the output directory
    os.makedirs(f"API_Functions/Darwin/Debug/{config.run_name}", exist_ok=True)
    shutil.copy(output_filename, f"API_Functions/Darwin/Debug/{config.run_name}/construct_gen.xml")

import shutil
import os

if __name__ == "__main__":
    # Example usage with configuration matching the original XML
    output_file_path = "API_Functions/Darwin/Debug/"
    for i in range(5):
        for strictness in [0.05, 0.2, 0.5]:
            for misses in [0.2, 0.4, 0.6]:
                strictness_string = str(strictness).replace(".", "_")
                misses_string = str(misses).replace(".", "_")
                config = ConstructConfig(
                    num_agents=100,
                    num_networks=3,
                    time_steps=365,
                    num_knowledge=1,
                    num_toxic=1,
                    time_period=864,
                    run_name=f"Full_Ban_{strictness_string}_{misses_string}_{i}",
                    seed=i,
                    main_rules={
                                "network_name": "Network1",
                                "rule": "true",
                                "toxicity threshold": strictness, #TODO: Make this a variable
                                "full ban": "true",
                                "partial ban": "false",
                                "warning": "false",
                                "remove content": "true",
                                "network ban threshold": "1",
                                "network warning threshold": "1",
                                "moderation miss probability": misses,
                                "partial ban length": "6"
                            }
                )
                create_construct_xml(config, output_file_path + f"Full_Ban_{strictness_string}_{misses_string}_{i}.xml")


    for i in range(5):
        for strictness in [0.05, 0.2, 0.5]:
            for misses in [0.2, 0.4, 0.6]:
                strictness_string = str(strictness).replace(".", "_")
                misses_string = str(misses).replace(".", "_")
                config = ConstructConfig(
                    num_agents=100,
                    num_networks=3,
                    time_steps=365,
                    num_knowledge=1,
                    num_toxic=1,
                    time_period=864,
                    run_name=f"Partial_Ban_{strictness_string}_{misses_string}_{i}",
                    seed=i,
                    main_rules={
                                "network_name": "Network1",
                                "rule": "true",
                                "toxicity threshold": strictness, #TODO: Make this a variable
                                "full ban": "false",
                                "partial ban": "true",
                                "warning": "false",
                                "remove content": "true",
                                "network ban threshold": "2",
                                "network warning threshold": "1",
                                "moderation miss probability": misses,
                                "partial ban length": "7"
                            }
                )
                create_construct_xml(config, output_file_path + f"Partial_Ban_{strictness_string}_{misses_string}_{i}.xml")

    for i in range(5):
        for strictness in [0.05, 0.2, 0.5]:
            for misses in [0.2, 0.4, 0.6]:
                strictness_string = str(strictness).replace(".", "_")
                misses_string = str(misses).replace(".", "_")
                config = ConstructConfig(
                    num_agents=100,
                    num_networks=3,
                    time_steps=365,
                    num_knowledge=1,
                    num_toxic=1,
                    time_period=864,
                    run_name=f"Warning_Full_Ban_{strictness_string}_{misses_string}_{i}",
                    seed=i,
                    main_rules={
                                "network_name": "Network1",
                                "rule": "true",
                                "toxicity threshold": strictness, #TODO: Make this a variable
                                "full ban": "true",
                                "partial ban": "false",
                                "warning": "true",
                                "remove content": "true",
                                "network ban threshold": "1",
                                "network warning threshold": "2",
                                "moderation miss probability": misses,
                                "partial ban length": "6"
                            }
                )
                create_construct_xml(config, output_file_path + f"Warning_Full_Ban_{strictness_string}_{misses_string}_{i}.xml")

    for i in range(5):
        for strictness in [0.05, 0.2, 0.5]:
            for misses in [0.2, 0.4, 0.6]:
                strictness_string = str(strictness).replace(".", "_")
                misses_string = str(misses).replace(".", "_")
                config = ConstructConfig(
                    num_agents=100,
                    num_networks=3,
                    time_steps=365,
                    num_knowledge=1,
                    num_toxic=1,
                    time_period=864,
                    run_name=f"Warning_Partial_Ban_{strictness_string}_{misses_string}_{i}",
                    seed=i,
                    main_rules={
                                "network_name": "Network1",
                                "rule": "true",
                                "toxicity threshold": strictness, #TODO: Make this a variable
                                "full ban": "false",
                                "partial ban": "true",
                                "warning": "true",
                                "remove content": "true",
                                "network ban threshold": "2",
                                "network warning threshold": "1",
                                "moderation miss probability": misses,
                                "partial ban length": "7"
                            }
                )
                create_construct_xml(config, output_file_path + f"Warning_Partial_Ban_{strictness_string}_{misses_string}_{i}.xml")

    



    """
    config = ConstructConfig(
        num_agents=50,
        num_networks=4,
        time_steps=1000,
        num_knowledge=1,
        num_toxic=1,
        run_name="Partial_Ban",
        main_rules={
            "network_name": "Network1",
            "rule": "true",
            "toxicity threshold": "0.05", #TODO: Make this a variable
            "full ban": "false",
            "partial ban": "true",
            "warning": "false",
            "remove content": "false",
            "network ban threshold": "1",
            "network warning threshold": "1",
            "moderation miss probability": "0.2",
            "partial ban length": "6"
        }
    )
    create_construct_xml(config)
    """

    """
    config = ConstructConfig(
        num_agents=50,
        num_networks=4,
        time_steps=1000,
        num_knowledge=1,
        num_toxic=1,
        run_name="Warning",
        main_rules={
            "network_name": "Network1",
            "rule": "true",
            "toxicity threshold": "0.05", #TODO: Make this a variable
            "full ban": "true",
            "partial ban": "false",
            "warning": "true",
            "remove content": "true",
            "network ban threshold": "1",
            "network warning threshold": "1",
            "moderation miss probability": "0.2",
            "partial ban length": "6"
        }
    )
    create_construct_xml(config)
    """
