#include "ToxicModel.h"
#include "Emotions.h"
#include "SocialMedia.h"

void ToxicModel::initialize()
{
  Social_Media_no_followers::initialize();

  age = 0.3;

  my_time = 0;
  my_dt = 0.1;
  my_age = 1;
}

item_keys getEventKeyFromParams(const dynet::ParameterMap &parameters)
{
  // TODO: Make this more elegant
  std::string event_key_str = parameters.get_parameter("network name");
  if (event_key_str == "twitter_event")
  {
    return item_keys::twitter_event;
  }
  else if (event_key_str == "facebook_event")
  {
    return item_keys::facebook_event;
  }
  else if (event_key_str == "Network1")
  {
    return item_keys::network1_event;
  }
  else if (event_key_str == "Network2")
  {
    return item_keys::network2_event;
  }
  else if (event_key_str == "Network3")
  {
    return item_keys::network3_event;
  }
  else if (event_key_str == "Network4")
  {
    return item_keys::network4_event;
  }
  else if (event_key_str == "Network5")
  {
    return item_keys::network5_event;
  }
  else if (event_key_str == "Network6")
  {
    return item_keys::network6_event;
  }
  else if (event_key_str == "Network7")
  {
    return item_keys::network7_event;
  }
  else if (event_key_str == "Network8")
  {
    return item_keys::network8_event;
  }
  else if (event_key_str == "Network9")
  {
    return item_keys::network9_event;
  }
  else if (event_key_str == "Network10")
  {
    return item_keys::network10_event;
  }

  // Add more conditions for other possible event keys

  // Default to twitter_event if no match is found
  return item_keys::twitter_event;
}

ToxicModel::ToxicModel(const dynet::ParameterMap &parameters, Construct &construct)
    : Social_Media_no_followers(parameters.get_parameter("network name"),
                                getEventKeyFromParams(parameters),
                                parameters, construct)

{
  influence_net = graph_manager.load_optional(NETWORK_INFLUENCE, agents, agents);
  agent_toxicity = graph_manager.load_required(TOXIC_INFLUENCE, agents, ns_manager.get_nodeset("toxic"));
  agent_susceptibility = graph_manager.load_required(TOXIC_SUSCEPTIBILITY, agents, ns_manager.get_nodeset("toxic"));

  network_name = parameters.get_parameter("network name");
  model_name = parameters.get_parameter("model name");

  toxicity_threshold = std::stof(parameters.get_parameter(node_attributes::toxicity_threshold));
  network_ban_threshold = std::stof(parameters.get_parameter(node_attributes::network_ban_threshold));
  network_warning_threshold = std::stof(parameters.get_parameter(node_attributes::network_warning_threshold));

  full_ban = parameters.get_parameter(node_attributes::full_ban) == "true";
  partial_ban = parameters.get_parameter(node_attributes::partial_ban) == "true";
  warning = parameters.get_parameter(node_attributes::warning) == "true";
  remove_content = parameters.get_parameter(node_attributes::remove_content) == "true";

  moderation_miss_probability = std::stof(parameters.get_parameter(node_attributes::moderation_miss_probability));

  network_index = ns_manager.get_nodeset("model").get_node_by_name(model_name)->index;
}

float ToxicModel::getSusceptibilityOfUser(int user_index, int susceptibility_index)
{
  return agent_susceptibility->at(user_index, susceptibility_index); // TODO: Update
}

void ToxicModel::setSusceptibility(int user_index, int susceptibility_index, float susceptibility)
{
  agent_susceptibility->at(user_index, susceptibility_index, susceptibility);
}

void ToxicModel::updateSusceptibility(int user_index, int susceptibility_index, float susceptibility)
{
  this->setSusceptibility(user_index, susceptibility_index, susceptibility);
}

float ToxicModel::getToxicityOfUser(int user_index, int toxicity_index)
{
  return agent_toxicity->at(user_index, toxicity_index);
}

Social_Media_no_followers::media_event *ToxicModel::create_post(unsigned int knowledge_index, unsigned int id)
{
  Social_Media_no_followers::media_event *post = Social_Media_no_followers::create_post(knowledge_index, id);
  addToxicityToEvent(id, post);
  post->time_stamp = construct.current_time;
  return post;
}

Social_Media_no_followers::media_event *ToxicModel::create_response(unsigned int id, Social_Media_no_followers::media_event *parent)
{
  auto *response = Social_Media_no_followers::create_response(id, parent);
  addToxicityToEvent(id, response);
  response->time_stamp = construct.current_time;
  return response;
}

Social_Media_no_followers::media_event *ToxicModel::create_quote(unsigned int id, Social_Media_no_followers::media_event *parent)
{
  auto *quote = Social_Media_no_followers::create_quote(id, parent);
  addToxicityToEvent(id, quote);
  quote->time_stamp = construct.current_time;
  return quote;
}

Social_Media_no_followers::media_event *ToxicModel::create_reply(unsigned int id, Social_Media_no_followers::media_event *parent)
{
  auto *reply = Social_Media_no_followers::create_reply(id, parent);
  addToxicityToEvent(id, reply);
  reply->time_stamp = construct.current_time;
  return reply;
}

Social_Media_no_followers::media_event *ToxicModel::create_repost(unsigned int id, Social_Media_no_followers::media_event *parent)
{
  auto *repost = Social_Media_no_followers::create_repost(id, parent);
  addToxicityToEvent(id, repost);
  repost->time_stamp = construct.current_time;
  return repost;
}

float ToxicModel::addToxicityToEvent(unsigned int id, Social_Media_no_followers::media_event *_event)
{

  bool should_add_toxicity = false;
  float user_toxicity = this->getToxicityOfUser(id, 0);

  if (user_toxicity > SERIAL_ABUSER_THRESHOLD)
  {
    // Return with 81.9% probability
    if (this->random.uniform() < SERIAL_TOXIC_POST_PROB)
      should_add_toxicity = true;
  }
  else if (user_toxicity > MODERATE_ABUSER_THRESHOLD)
  {
    // Check for previous moderation
    bool warned = warning_network->at(id, network_index);

    if (warned and this->random.uniform() > 0.5)
      // Return with 93.2% probability
      if (this->random.uniform() < MODERATE_TOXIC_POST_PROB)
        should_add_toxicity = true;
  }
  else
  {
    // Check for previous moderation
    bool warned = warning_network->at(id, network_index);

    if (!warned)
      // Return with 98% probability
      if (this->random.uniform() < OCCASIONAL_TOXIC_POST_PROB)
        should_add_toxicity = true;
  }

  if (should_add_toxicity)
  {

    float toxicity = this->random.uniform(0, user_toxicity); // TODO: Make this more nuanced
    _event->attributes.insert(item_keys::toxicity);
    _event->values[item_keys::toxicity] = toxicity;
    _event->indexes[item_keys::toxicity] = 0;
  }
}

// Calculate new toxicity from messages
void ToxicModel::think(void)
{
  Social_Media_no_followers::think();
}

void ToxicModel::update(void)
{
  Social_Media_no_followers::update();
}

void ToxicModel::communicate(const InteractionMessage &msg)
{
  Social_Media_no_followers::communicate(msg);
}

bool ToxicModel::intercept(InteractionItem &item, unsigned int sender, unsigned int receiver, const CommunicationMedium *medium)
{
  bool result = Social_Media_no_followers::intercept(item, sender, receiver, medium);
  return result;
}

void ToxicModel::cleanup(void)
{
  int start_time = clock();
  Social_Media_no_followers::cleanup();
  int end_time = clock();
  std::cout << "Time taken for toxic random_event_swapping: " << (end_time - start_time) / (double)CLOCKS_PER_SEC << " seconds" << std::endl;
}