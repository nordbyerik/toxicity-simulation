#pragma once

#include <string>
#include "Emotions.h"

#include "ToxicModelDefinition.h"
#include "ToxicUser.h"
#include "SocialMedia.h"

namespace node_attributes
{
  const std::string toxicity_threshold = "toxicity threshold";
  const std::string network_ban_threshold = "network ban threshold";
  const std::string network_warning_threshold = "network warning threshold";

  const std::string full_ban = "full ban";
  const std::string partial_ban = "partial ban";
  const std::string warning = "warning";
  const std::string remove_content = "remove content";

  const std::string moderation_miss_probability = "moderation miss probability";
  const std::string partial_ban_length = "partial ban length";
}

struct ToxicModel : virtual public Social_Media_no_followers
{

public:
  // Constructor
  ToxicModel(const dynet::ParameterMap &parameters, Construct &construct);

  unsigned int network_index;
  std::string model_name;
  std::string network_name;

  // Override methods
  void initialize() override;
  void think() override;
  void update() override;
  void communicate(const InteractionMessage &msg) override;
  bool intercept(InteractionItem &item, unsigned int sender, unsigned int receiver, const CommunicationMedium *medium) override;
  void cleanup() override;

  // Get default media user
  Social_Media_no_followers::media_user *get_default_media_user(const Node &node) override { return new ToxicUser(this, node); }

  // Factory methods for creating media events
  media_event *create_post(unsigned int knowledge_index, unsigned int id) override;
  media_event *create_response(unsigned int id, media_event *parent) override;
  media_event *create_quote(unsigned int id, media_event *parent) override;
  media_event *create_reply(unsigned int id, media_event *parent) override;
  media_event *create_repost(unsigned int id, media_event *parent) override;

  // Accessor methods
  float getToxicityOfUser(int user_index, int toxicity_index);
  float getSusceptibilityOfUser(int user_index, int susceptibility_index);

  // Calculate toxicity
  float calculateToxicity(media_event *event);
  float calculateToxicity(float agent_toxicity, float knowledge_toxicity, float susceptibility);
  float addToxicityToEvent(unsigned int id, Social_Media_with_followers::media_event *_event);

  bool my_active(Social_Media_with_followers::media_event &event);

  Graph<unsigned int> *warning_network = graph_manager.load_required("warning network", nodeset_names::agents, nodeset_names::model);
  Graph<unsigned int> *ban_network = graph_manager.load_required("ban network", nodeset_names::agents, nodeset_names::model);
  Graph<int> *toxicity_overload_network = graph_manager.load_required("toxicity overload network", nodeset_names::agents, nodeset_names::model);

  bool full_ban;
  bool partial_ban;
  bool warning;
  bool remove_content;

  int partial_ban_length;

  float SERIAL_ABUSER_THRESHOLD = 0.96f;
  float MODERATE_ABUSER_THRESHOLD = 0.71f;

  float SERIAL_TOXIC_POST_PROB = 0.181f;
  float MODERATE_TOXIC_POST_PROB = 0.072f;
  float OCCASIONAL_TOXIC_POST_PROB = 0.02f;

  float SERIAL_TOXIC_RESPONSE_PROB = 0.50f;
  float MODERATE_TOXIC_RESPONSE_PROB = 0.20f;
  float OCCASIONAL_TOXIC_RESPONSE_PROB = 0.10f;

  float moderation_miss_probability;

  float toxicity_threshold;
  unsigned int network_ban_threshold;
  unsigned int network_warning_threshold;

  float my_time = 0;
  float my_dt = 0.1;
  float my_age = 1;

private:
  // Helper methods
  void setToxic(int user_index, int toxicity_index, float toxic);
  void updateToxic(int user_index, int toxicity_index, float amount);
  void syncNetworks(int timestamp);
  void setSusceptibility(int user_index, int susceptibility_index, float susceptibility);
  void updateSusceptibility(int user_index, int susceptibility_index, float susceptibility);

  // Member variables
  float lr = 0.2f;

  Graph<float> *influence_net;
  Graph<float> *agent_toxicity;
  Graph<float> *agent_susceptibility;
  Graph<float> *knowledge_toxicity;

  const Nodeset &toxic_items = ns_manager.get_nodeset(nodeset_names::toxic);
};
