#pragma once

#include "MultiplatformSocialMedia.h"
#include "ToxicModel.h"

struct ToxicModeration : public Multiplatform_Manager
{

    ToxicModeration(const dynet::ParameterMap &parameters, Construct &construct);

    void initialize() override;

    void think() override;

    float toxicity_threshold;

    int moderation_style;

    bool intercept(InteractionItem &item, unsigned int sender, unsigned int receiver, const CommunicationMedium *medium) override;

    virtual bool should_moderate_user(InteractionItem &item, unsigned int sender, const CommunicationMedium *medium, float moderation_threshold);

    Graph<unsigned int> *warning_network = graph_manager.load_required("warning network", nodeset_names::agents, nodeset_names::model);
    Graph<unsigned int> *partial_ban_network = graph_manager.load_required("partial ban network", nodeset_names::agents, nodeset_names::model);
    Graph<unsigned int> *ban_network = graph_manager.load_required("ban network", nodeset_names::agents, nodeset_names::model);
    Graph<int> *toxicity_overload_network = graph_manager.load_required("toxicity overload network", nodeset_names::agents, nodeset_names::model);
    Graph<bool> *toxicity_overload_tracker = graph_manager.load_required("toxicity overload tracker", nodeset_names::agents, nodeset_names::model);
    Graph<bool> *agent_activity_on_platforms = graph_manager.load_required("agent activity on platforms", nodeset_names::agents, nodeset_names::model);

    void partially_ban(unsigned int user_index);
    void full_ban(unsigned int user_index);

    void update_preferences(unsigned int user_index, const CommunicationMedium *medium);

    void moderation_response(unsigned int sender, const CommunicationMedium *medium);
};