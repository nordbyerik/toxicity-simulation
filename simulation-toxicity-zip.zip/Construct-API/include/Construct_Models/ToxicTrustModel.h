#pragma once
#include "KnowledgeTrust.h"

struct ToxicTrustModel : public Trust
{
    ToxicTrustModel(const dynet::ParameterMap &parameters, Construct &construct);

    void initialize(void) override;

    void update(void) override;

    bool intercept(InteractionItem &item, unsigned int sender, unsigned int receiver, const CommunicationMedium *medium) override;

    void communicate(const InteractionMessage &msg) override;

    void cleanup(void) override;
};