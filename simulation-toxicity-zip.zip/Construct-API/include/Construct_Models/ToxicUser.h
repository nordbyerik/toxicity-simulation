#pragma once
#include "SocialMedia.h"
#include "Emotions.h"

struct ToxicUser : public virtual Social_Media_no_followers::default_media_user
{
    ToxicUser(Social_Media_no_followers *_media, const Node &_node);

    unsigned int network_index;
    int num_platforms;
    unsigned int get_knowledge_selection(void) override;

    void parse(Social_Media_no_followers::media_event *_event) override;
    void reply(Social_Media_no_followers::media_event *_event) override;
    void quote(Social_Media_no_followers::media_event *_event) override;
    void repost(Social_Media_no_followers::media_event *_event) override;

    float SERIAL_ABUSER_THRESHOLD = 0.96f;
    float MODERATE_ABUSER_THRESHOLD = 0.71f;

    float SERIAL_TOXIC_POST_PROB = 0.181f;
    float MODERATE_TOXIC_POST_PROB = 0.072f;
    float OCCASIONAL_TOXIC_POST_PROB = 0.02f;

    float SERIAL_TOXIC_RESPONSE_PROB = 0.50f;
    float MODERATE_TOXIC_RESPONSE_PROB = 0.20f;
    float OCCASIONAL_TOXIC_RESPONSE_PROB = 0.10f;

    // TODO: Ngl this seems gross
    const Nodeset &toxic_items = media().ns_manager.get_nodeset(nodeset_names::toxic);
    Graph<float> *agent_toxicity = media().graph_manager.load_required("toxic agent network", media().ns_manager.get_nodeset("agent"), media().ns_manager.get_nodeset("toxic"));

    Graph<unsigned int> *warning_network = media().graph_manager.load_required("warning network", media().ns_manager.get_nodeset("agent"), media().ns_manager.get_nodeset("model"));
    Graph<unsigned int> *ban_network = media().graph_manager.load_required("ban network", media().ns_manager.get_nodeset("agent"), media().ns_manager.get_nodeset("model"));
    Graph<int> *toxicity_overload_network = media().graph_manager.load_required("toxicity overload network", media().ns_manager.get_nodeset("agent"), media().ns_manager.get_nodeset("model"));

    Graph<float> &_platform_switch_probabilities = media().graph_manager.load_optional("platform switch probability network", 0.1f, media().ns_manager.get_nodeset("agent"), sparse, media().ns_manager.get_nodeset("model"), sparse);

    Graph<float> &_platform_preference_weigths = media().graph_manager.load_optional("platform preference network", 1.0f, media().ns_manager.get_nodeset("agent"), sparse, media().ns_manager.get_nodeset("model"), sparse);

    const Nodeset &models = media().ns_manager.get_nodeset(nodeset_names::model);

    float getToxicityOfUser(int user_index, int toxicity_index);
    void setToxicityOfUser(int user_index, int toxicity_index, float toxicity);
    float getToxicityOfKnowledge(int knowledge_index, int toxicity_index);

    unsigned int get_network_index(void);

    void generate_post_events(void) override;
    unsigned int get_read_count(void) override;
    void enrich_event(Social_Media_no_followers::media_event *_event) override;
    std::set<Social_Media_no_followers::media_event *> read(Social_Media_no_followers::media_event *read_event) override;
};