#ifndef TOXIC_MODEL_DEFINITION
#define TOXIC_MODEL_DEFINITION

const static char *MODEL_TOXIC = "Toxicity Model";

const static char *NETWORK_INFLUENCE = "influence network";
const static char *TOXIC_INFLUENCE = "toxic agent network";
const static char *TOXIC_SUSCEPTIBILITY = "toxic susceptibility network";
const static float STRUCTURAL_LEARNING_RATE = 0.1;

#endif // !TOXIC_MODEL_DEFINITION