#include "ToxicModeration.h"
#include "../CustomKeys.h"

ToxicModeration::ToxicModeration(const dynet::ParameterMap &parameters, Construct &construct) : Multiplatform_Manager(construct)
{
}

void ToxicModeration::initialize()
{
    Multiplatform_Manager::initialize();
}

void ToxicModeration::think()
{
    // Measuring time to complete
    Multiplatform_Manager::think();
    // Check if any agents are overloaded with toxicity and want to respond

    // Log active agents for each platform
    for (const auto &platform : moderated_platforms)
    {
        auto platform_index = platform.second.index;
        auto active_agents = platform.second.active_agent;
        for (const Node &agent : agents)
            agent_activity_on_platforms->at(agent.index, platform_index) = active_agents->at(agent.index, construct.current_time);
    }

    // For each agent
    for (const Node &i : agents)
    {
        for (const Node &j : models)
        {
            // Check if any agents want to move to a different platform
            int toxicity_overload_count = toxicity_overload_network->at(i.index, j.index);
            while (toxicity_overload_count > 0)
            {
                // Agent gets too scared
                const CommunicationMedium *medium = platform_medium[j.index];
                ToxicModeration::moderation_response(i.index, medium);
                toxicity_overload_count -= 1;
                toxicity_overload_tracker->at(i.index, j.index) = 1;
            }
            toxicity_overload_network->at(i.index, j.index) = 0;

            // Decrement any partial bans
            if (partial_ban_network->at(i.index, j.index) > 0)
            {
                partial_ban_network->at(i.index, j.index) -= 1;
            }
        }
    }
}

bool ToxicModeration::intercept(InteractionItem &item, unsigned int sender, unsigned int receiver, const CommunicationMedium *medium)
{

    // User medium to select platform
    ToxicModel *platform_full = dynamic_cast<ToxicModel *>(moderated_platforms.at(medium).platform);
    int platform_index = moderated_platforms.at(medium).index;

    // If the user is banned, return false
    bool banned = false;
    bool permanently_banned = ban_network->at(sender, platform_index) >= platform_full->network_ban_threshold;
    bool partially_banned = partial_ban_network->at(sender, platform_index) > 0;
    if (permanently_banned || partially_banned)
    {
        ToxicModeration::moderation_response(sender, medium);
        return true;
    }

    bool should_intercept = should_moderate_user(item, sender, medium, platform_full->toxicity_threshold);

    // Misses moderation with some probability
    if (this->random.uniform() < platform_full->moderation_miss_probability)
        should_intercept = false;

    // If warning, add to warning network
    bool just_warned = false;
    if (platform_full->warning && should_intercept && warning_network->at(sender, platform_index) < platform_full->network_warning_threshold)
    {
        warning_network->at(sender, platform_index) += 1;
    }
    else if (platform_full->partial_ban && should_intercept)
    {
        ban_network->at(sender, platform_index) += 1;
        partial_ban_network->at(sender, platform_index) += platform_full->partial_ban_length;
    }
    else if (platform_full->full_ban && should_intercept)
    {
        ban_network->at(sender, platform_index) = platform_full->network_ban_threshold;
    }

    // If no remove content, return false
    if (!platform_full->remove_content)
        should_intercept = false;

    if (should_intercept)
    {
        ToxicModeration::moderation_response(sender, medium);
    }

    return should_intercept;
}

bool ToxicModeration::should_moderate_user(InteractionItem &item, unsigned int sender, const CommunicationMedium *medium, float moderation_threshold)
{
    bool result = false;

    if (item.values.find(item_keys::toxicity) != item.values.end())
    {
        float toxicity = item.values[item_keys::toxicity];
        if (toxicity > moderation_threshold)
        {
            result = true;
        }
    }

    return result;
}

void ToxicModeration::moderation_response(unsigned int sender, const CommunicationMedium *medium)
{
    // Update the preferences. Rotate the current platform & all platforms with lower weight
    // So if most preferred platform is being moderated, all platform weights are rotated
    // If the second most preferred platform is being moderated, the second platform and all platforms with lower weight are rotated
    int platform_index = moderated_platforms.at(medium).index;
    float ref_weight = _platform_preference_weigths.at(sender, platform_index);

    // Collect and sort weights less than reference value
    std::vector<std::pair<size_t, float>> lower_weights;
    for (size_t i = 0; i < moderated_platforms.size(); i++)
    {
        float weight = _platform_preference_weigths.at(sender, i);
        if (weight <= ref_weight)
        {
            lower_weights.push_back({i, weight});
        }
    }

    // Sort by weight value in descending order
    std::sort(lower_weights.begin(), lower_weights.end(),
              [](const auto &a, const auto &b)
              { return a.second > b.second; });

    // Step 3: Rotate indices in the vector
    if (!lower_weights.empty())
    {
        auto last_pair = lower_weights.back();
        for (size_t i = lower_weights.size() - 1; i > 0; --i)
        {
            lower_weights[i].second = lower_weights[i - 1].second;
        }
        lower_weights.front().second = last_pair.second;
    }

    // Step 4: Insert the rotated weights into their respective positions
    for (const auto &[index, weight] : lower_weights)
    {
        _platform_preference_weigths.at(sender, index) = weight;
    }

    Multiplatform_Manager::moderation_response(sender, medium);
}
