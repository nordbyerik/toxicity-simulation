#pragma once

#include <string>

#include "Emotions.h"

struct SocialMediaGeneralizedName : public SM_wf_emotions
{

public:
    // Constructor
    SocialMediaGeneralizedName(const dynet::ParameterMap &parameters, Construct &construct);
};
