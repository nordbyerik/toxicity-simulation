#include "ToxicUser.h"
#include "ToxicModel.h"
#include "../CustomKeys.h"

ToxicUser::ToxicUser(Social_Media_no_followers *_media, const Node &_node) : Social_Media_no_followers::default_media_user(_media, _node)
{
    network_index = dynamic_cast<ToxicModel *>(_media)->network_index;
}

unsigned int ToxicUser::get_knowledge_selection(void)
{
    return Social_Media_no_followers::default_media_user::get_knowledge_selection();
}

void ToxicUser::parse(Social_Media_no_followers::media_event *_event)
{
    if (_event->attributes.find(item_keys::toxicity) != _event->attributes.end())
    {
        // Read the event and update our toxicity
        float toxicity = _event->values[item_keys::toxicity];
        float current_toxicity = this->getToxicityOfUser(id, 0);

        // If the toxicity is too high, set the toxicity overload network
        if (toxicity > this->getToxicityOfUser(id, 0))
        {
            toxicity_overload_network->at(id, network_index) += 1;
        }
    }
    Social_Media_no_followers::default_media_user::parse(_event);
}

void ToxicUser::reply(Social_Media_no_followers::media_event *_event)
{
    if(this->random().uniform() < 0.33)
        Social_Media_no_followers::default_media_user::reply(_event);
}

void ToxicUser::quote(Social_Media_no_followers::media_event *_event)
{
    if(this->random().uniform() < 0.33)
        Social_Media_no_followers::default_media_user::quote(_event);
}

void ToxicUser::repost(Social_Media_no_followers::media_event *_event)
{
    if(this->random().uniform() < 0.33)
        Social_Media_no_followers::default_media_user::repost(_event);
}

void ToxicUser::generate_post_events(void)
{
    Social_Media_no_followers::default_media_user::generate_post_events();
}

unsigned int ToxicUser::get_read_count(void)
{
    return Social_Media_no_followers::default_media_user::get_read_count();
}

float ToxicUser::getToxicityOfUser(int user_index, int toxicity_index)
{
    // TODO: I'd rather use existing functions to get the toxicity of a user
    //  but I'm not sure how to do that
    return agent_toxicity->at(user_index, toxicity_index);
}

void ToxicUser::setToxicityOfUser(int user_index, int toxicity_index, float toxicity)
{
    agent_toxicity->at(user_index, toxicity_index) = toxicity;
}

void ToxicUser::enrich_event(Social_Media_no_followers::media_event *_event)
{
    Social_Media_no_followers::default_media_user::enrich_event(_event);
};

std::set<Social_Media_no_followers::media_event *> ToxicUser::read(Social_Media_no_followers::media_event *read_event)
{

    if (read_event->attributes.find(item_keys::toxicity) != read_event->attributes.end())
    {
        // Read the event and update our toxicity
        float toxicity = read_event->values[item_keys::toxicity];
        float current_toxicity = this->getToxicityOfUser(id, 0);

        // If the toxicity is too high, set the toxicity overload network
        if (toxicity > this->getToxicityOfUser(id, 0))
            toxicity_overload_network->at(id, network_index) += 1;
    }

    return Social_Media_no_followers::default_media_user::read(read_event);
}