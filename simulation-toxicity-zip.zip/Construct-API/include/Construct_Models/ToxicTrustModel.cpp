#include "ToxicTrustModel.h"

ToxicTrustModel::ToxicTrustModel(const dynet::ParameterMap &parameters, Construct &construct) : Trust(parameters, construct) {}

void ToxicTrustModel::initialize(void)
{
    Trust::initialize();
}

void ToxicTrustModel::update(void)
{
    Trust::update();
}

bool ToxicTrustModel::intercept(InteractionItem &item, unsigned int sender, unsigned int receiver, const CommunicationMedium *medium)
{
    bool result = Trust::intercept(item, sender, receiver, medium);
    return result;
}

void ToxicTrustModel::communicate(const InteractionMessage &msg)
{
    Trust::communicate(msg);
}

void ToxicTrustModel::cleanup(void)
{
    Trust::cleanup();
}
