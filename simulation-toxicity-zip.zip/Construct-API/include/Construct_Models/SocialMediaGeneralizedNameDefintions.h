#ifndef TOXIC_MODEL_DEFINITION
#define TOXIC_MODEL_DEFINITION

const static char *MODEL_TOXIC = "Social Media Generalized Model";

#endif // !TOXIC_MODEL_DEFINITION