import { useState, useEffect } from 'react';
import _ from 'lodash';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function ComparativeAnalysis() {
    const [data, setData] = useState({
      timeComparison: [],
      agentComparison: [],
      interactionComparison: [],
      knowledgeLevels: []
    });
    
    useEffect(() => {
      const loadData = async () => {
        const file1 = await fetch('/data/toxic_1.json').then(res => res.text());
        const file2 = await fetch('/data/toxic_2.json').then(res => res.text());
  
        
        const data1 = JSON.parse(file1);
        const data2 = JSON.parse(file2);
        
        // Time-based message counts
        const timeData = _.range(0, 10).map(time => ({
          period: time,
          'Dataset 1': data1.data.filter(m => m.created_at === time).length,
          'Dataset 2': data2.data.filter(m => m.created_at === time).length
        }));
  
        // Agent activity comparison
        const agents = _.uniq([
          ...data1.data.map(m => m.author_id),
          ...data2.data.map(m => m.author_id)
        ]);
        
        const agentData = agents.map(agent => ({
          agent,
          'Dataset 1': data1.data.filter(m => m.author_id === agent).length,
          'Dataset 2': data2.data.filter(m => m.author_id === agent).length
        }));
  
        // Interaction types
        const getInteractions = (data) => {
          const interactions = data.data.filter(m => m.referenced_tweets?.length > 0);
          return {
            replies: interactions.filter(m => m.referenced_tweets.some(t => t.type === 'replied_to')).length,
            quotes: interactions.filter(m => m.referenced_tweets.some(t => t.type === 'quoted')).length,
            retweets: interactions.filter(m => m.referenced_tweets.some(t => t.type === 'retweeted')).length
          };
        };
  
        const int1 = getInteractions(data1);
        const int2 = getInteractions(data2);
        
        const interactionData = [
          { type: 'Replies', 'Dataset 1': int1.replies, 'Dataset 2': int2.replies },
          { type: 'Quotes', 'Dataset 1': int1.quotes, 'Dataset 2': int2.quotes },
          { type: 'Retweets', 'Dataset 1': int1.retweets, 'Dataset 2': int2.retweets }
        ];
  
        // Knowledge levels
        const getKnowledgeLevels = (data) => {
          return _.countBy(data.data, m => m.entities?.indexes?.[0]?.knowledge ?? 'undefined');
        };
  
        const k1 = getKnowledgeLevels(data1);
        const k2 = getKnowledgeLevels(data2);
        
        const knowledgeData = [0, 1, 2].map(level => ({
          level: `Level ${level}`,
          'Dataset 1': k1[level] || 0,
          'Dataset 2': k2[level] || 0
        }));
  
        setData({
          timeComparison: timeData as never[],
          agentComparison: _.sortBy(agentData, [a => -(a['Dataset 1'] + a['Dataset 2'])]) as never[],
          interactionComparison: interactionData as never[],
          knowledgeLevels: knowledgeData as never[]
        });
      };
  
      loadData();
    }, []);
  
    return (
      <div className="max-w-7xl mx-auto p-8 bg-white">
        <h1 className="text-2xl font-normal text-gray-800 mb-8">Comparative Network Analysis</h1>
        
        <div className="grid grid-cols-1 gap-12">
          <section>
            <h2 className="text-lg font-normal text-gray-800 mb-4">Temporal Message Distribution</h2>
            <div className="h-80 bg-white">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={data.timeComparison}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
                  <XAxis dataKey="period" label={{ value: 'Time Period', position: 'bottom' }} />
                  <YAxis label={{ value: 'Message Count', angle: -90, position: 'insideLeft' }} />
                  <Tooltip />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="Dataset 1"
                    stroke="#000"
                    strokeWidth={1.5}
                    dot={{ fill: '#000' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="Dataset 2"
                    stroke="#666"
                    strokeWidth={1.5}
                    dot={{ fill: '#666' }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </section>
  
          <section>
            <h2 className="text-lg font-normal text-gray-800 mb-4">Agent Activity Distribution</h2>
            <div className="h-80 bg-white">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.agentComparison} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
                  <XAxis type="number" />
                  <YAxis dataKey="agent" type="category" width={80} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="Dataset 1" fill="#000" />
                  <Bar dataKey="Dataset 2" fill="#666" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </section>
  
          <section className="grid grid-cols-2 gap-8">
            <div>
              <h2 className="text-lg font-normal text-gray-800 mb-4">Interaction Types</h2>
              <div className="h-80 bg-white">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.interactionComparison}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
                    <XAxis dataKey="type" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="Dataset 1" fill="#000" />
                    <Bar dataKey="Dataset 2" fill="#666" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
  
            <div>
              <h2 className="text-lg font-normal text-gray-800 mb-4">Knowledge Level Distribution</h2>
              <div className="h-80 bg-white">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.knowledgeLevels}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
                    <XAxis dataKey="level" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="Dataset 1" fill="#000" />
                    <Bar dataKey="Dataset 2" fill="#666" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </section>
        </div>
      </div>
    );
  };