'use client'; // Add this at the top of the file

import React, { useState, useEffect } from 'react';
import { 
  LineChart, 
  Line, 
  BarChart,  // Added this
  Bar,       // Make sure I have this too
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import _ from 'lodash';

import Results from './results'
export default function Home() {
  return (
    <main>
      <ResearchPaper />
    </main>
  )
}

const ResearchPaper = () => {
  // State management for different sections and visualizations
  const [activeSection, setActiveSection] = useState('abstract');
  const [data, setData] = useState({
    toxicityData: [],
    platformData: [],
    migrationData: []
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading data
    setTimeout(() => {
      setData({
        toxicityData: generateToxicityData() as never[],
        platformData: generatePlatformData() as never[],
        migrationData: generateMigrationData() as never[]
      });
      setIsLoading(false);
    }, 500);
  }, []);

  const TableOfContents = () => (
    <nav className="sticky top-4 p-4 bg-gray-50 rounded-lg">
      <h3 className="text-lg font-semibold mb-4">Contents</h3>
      <ul className="space-y-2">
        {['Abstract', 'Introduction', 'Methods', 'Results', 'Discussion', 'Conclusion'].map(section => (
          <li key={section}>
            <button
              onClick={() => setActiveSection(section.toLowerCase())}
              className={`text-left w-full px-2 py-1 rounded ${
                activeSection === section.toLowerCase() 
                  ? 'bg-blue-100 text-blue-800' 
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              {section}
            </button>
          </li>
        ))}
      </ul>
    </nav>
  );

  if (isLoading) {
    return <div className="max-w-7xl mx-auto p-8">Loading research paper...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-4 gap-8">
        {/* Left sidebar with table of contents */}
        <aside className="col-span-1">
          <TableOfContents />
        </aside>

        {/* Main content area */}
        <main className="col-span-3 bg-white rounded-lg shadow-sm p-8">
          {/* Paper Header */}
          <header className="mb-12 pb-8 border-b">
            <h1 className="text-4xl font-serif mb-6">
              Impact of Content Moderation Strategies on Cross-Platform Toxicity: An Agent-Based Analysis
            </h1>
            <div className="text-gray-600 mb-4">
              <p className="mb-2">Erik Nordby</p>
              <p className="mb-2">Georgia Institute of Technology (OMSCS Student)</p>
              <p>Date: {new Date().toLocaleDateString()}</p>
            </div>
          </header>

          {/* Abstract Section */}
          <section id="abstract" className={`mb-12 ${activeSection !== 'abstract' && 'hidden'}`}>
            <h2 className="text-2xl font-serif mb-4">Abstract</h2>
            <p className="text-gray-800 leading-relaxed mb-4">
              This paper examines the impact of varying content moderation strategies on user behavior 
              and toxicity levels across multiple social media platforms. Using agent-based modeling, 
              I simulate user interactions and content diffusion patterns to understand how different 
              moderation approaches affect both individual platforms and the broader social media ecosystem.
            </p>
            <p className="text-gray-800 leading-relaxed">
              Our findings suggest that while strict moderation can effectively reduce toxicity on individual 
              platforms, it may lead to increased toxicity on alternative platforms with less stringent 
              moderation policies. I propose a framework for evaluating the systemic impact of moderation 
              strategies and suggest approaches for cross-platform coordination.
            </p>
          </section>

          {/* Introduction Section */}
          <section id="introduction" className={`mb-12 ${activeSection !== 'introduction' && 'hidden'}`}>
            <h2 className="text-2xl font-serif mb-4">Introduction</h2>
            <p className="text-gray-800 leading-relaxed mb-4">
              Content moderation on social media platforms has become increasingly crucial as online 
              toxicity continues to impact user experience and platform health. While individual platforms 
              have implemented various moderation strategies, the interconnected nature of the social media 
              ecosystem means that actions taken on one platform can have ripple effects across others.
            </p>
            
            <div className="bg-gray-50 p-6 rounded-lg mb-6">
              <h3 className="text-xl font-semibold mb-4">Research Questions</h3>
              <ul className="list-disc pl-6 space-y-2">
                <li>How do different moderation strategies impact overall system-wide toxicity?</li>
                <li>What are the patterns of user migration between platforms with varying moderation policies?</li>
                <li>How do network effects influence the effectiveness of moderation strategies?</li>
              </ul>
            </div>

            <p className="text-gray-800 leading-relaxed">
              Through agent-based modeling, I examine these questions by simulating user behavior across 
              multiple platforms. Our model incorporates key factors such as content toxicity, user 
              interaction patterns, and platform moderation policies to provide insights into the complex 
              dynamics of cross-platform content moderation.
            </p>
          </section>

          {/* Methods Section */}
          <section id="methods" className={`mb-12 ${activeSection !== 'methods' && 'hidden'}`}>
            <h2 className="text-2xl font-serif mb-6">Methods</h2>
            
            <h3 className="text-xl font-semibold mb-4">Simulation Environment</h3>
            <p className="text-gray-800 leading-relaxed mb-6">
              I utilized the Construct simulation framework to model user behavior and platform dynamics. 
              The simulation environment includes multiple social media platforms with varying moderation 
              policies, user agents with different behavioral characteristics, and mechanisms for content 
              creation and interaction.
            </p>

            <div className="bg-white border border-gray-200 rounded-lg p-6 mb-8">
              <h4 className="text-lg font-semibold mb-4">Key Parameters</h4>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="font-mono bg-gray-100 px-2 py-1 rounded mr-3">userCount</span>
                  <span>Number of user agents in the simulation</span>
                </li>
                <li className="flex items-start">
                  <span className="font-mono bg-gray-100 px-2 py-1 rounded mr-3">toxicityThreshold</span>
                  <span>Threshold for content to be considered toxic</span>
                </li>
                <li className="flex items-start">
                  <span className="font-mono bg-gray-100 px-2 py-1 rounded mr-3">moderationStrength</span>
                  <span>Intensity of moderation actions (0-1)</span>
                </li>
              </ul>
            </div>

            <h3 className="text-xl font-semibold mb-4">Data Collection</h3>
            <p className="text-gray-800 leading-relaxed mb-6">
              During each simulation run, I collected data on:
            </p>
            <ul className="list-disc pl-6 mb-6 space-y-2">
              <li>User interaction patterns</li>
              <li>Content toxicity levels</li>
              <li>Platform migration events</li>
              <li>Network structure metrics</li>
            </ul>

          </section>

          {/* Results Section */}
          <section id="results" className={`mb-12 ${activeSection !== 'results' && 'hidden'}`}>
            <Results />
          </section>

          {/* Discussion Section */}
          <section id="discussion" className={`mb-12 ${activeSection !== 'discussion' && 'hidden'}`}>
            <h2 className="text-2xl font-serif mb-6">Discussion</h2>
            
            <div className="space-y-6">
              <p className="text-gray-800 leading-relaxed">
                Our results demonstrate the complex interplay between moderation strategies and user 
                behavior across social media platforms. While strict moderation effectively reduces 
                toxicity on individual platforms, the migration of users to less moderated platforms 
                creates new challenges for the broader social media ecosystem.
              </p>

              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                <h3 className="text-lg font-semibold mb-2">Implications for Platform Governance</h3>
                <p className="text-gray-700">
                  The findings suggest that effective content moderation requires coordination between 
                  platforms to prevent the concentration of toxic behavior in unmoderated spaces.
                </p>
              </div>

              <h3 className="text-xl font-semibold mt-8 mb-4">Limitations</h3>
              <ul className="list-disc pl-6 space-y-2 text-gray-800">
                <li>Simplified user behavior models</li>
                <li>Limited consideration of external factors</li>
                <li>Assumption of perfect moderation implementation</li>
              </ul>
            </div>
          </section>

          {/* Conclusion Section */}
          <section id="conclusion" className={`mb-12 ${activeSection !== 'conclusion' && 'hidden'}`}>
            <h2 className="text-2xl font-serif mb-6">Conclusion</h2>
            
            <p className="text-gray-800 leading-relaxed mb-6">
            This study provides evidence that while platform-specific moderation can be effective, 
              the interconnected nature of social media platforms requires a more holistic approach 
              to content moderation. Future research should focus on developing coordinated 
              moderation frameworks that consider the systemic impact of platform policies.
            </p>

            <div className="bg-blue-50 border-l-4 border-blue-400 p-4">
              <h3 className="text-lg font-semibold mb-2">Future Directions</h3>
              <ul className="space-y-2 text-gray-700">
                <li>Development of cross-platform moderation standards</li>
                <li>Investigation of user rehabilitation strategies</li>
                <li>Analysis of long-term ecosystem stability</li>
              </ul>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
};

// Helper functions for generating sample data
const generateToxicityData = () => {
  return Array.from({ length: 12 }, (_, i) => ({
    period: `Period ${i + 1}`,
    highMod: 100 - Math.exp(i / 4),
    lowMod: 100 - Math.exp(i / 8)
  }));
};

const generatePlatformData = () => {
  return [
    { platform: 'Platform A', toxicity: 45, engagement: 80 },
    { platform: 'Platform B', toxicity: 65, engagement: 60 },
    { platform: 'Platform C', toxicity: 30, engagement: 90 },
    { platform: 'Platform D', toxicity: 75, engagement: 40 }
  ];
};

const generateMigrationData = () => {
  return Array.from({ length: 6 }, (_, i) => ({
    month: `Month ${i + 1}`,
    migrations: Math.floor(Math.random() * 1000)
  }));
};
