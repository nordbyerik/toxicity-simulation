import React, { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import Papa from 'papaparse';
import _ from 'lodash';
import { AlertCircle, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Data, Layout } from 'plotly.js';

interface DataPoint {
  time_period: number;
  [key: string]: number;
}

const Plot = dynamic(() => import('react-plotly.js'), {
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center h-96">
      <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
    </div>
  )
});

const ToxicityAnalysis = () => {
  const [data, setData] = useState<DataPoint[]>([]);
  const [platforms, setPlatforms] = useState<string[]>([]);
  const [selectedRun, setSelectedRun] = useState('run8');
  const [status, setStatus] = useState('loading');
  const [error, setError] = useState<string | null>(null);

  // Modern, minimal color palette matching the violin plot
  const colors = [
    '#3b82f6', // Primary blue
    '#22c55e', // Fresh green
    '#a855f7', // Soft purple
    '#f97316', // Subtle orange
  ];

  useEffect(() => {
    const loadData = async () => {
      setStatus('loading');
      try {
        const response = await fetch(`processed_data/${selectedRun}/platform_activity.csv`);
        const csvText = await response.text();
        
        Papa.parse(csvText, {
          header: true,
          dynamicTyping: true,
          skipEmptyLines: true,
          complete: (results) => {
            if (results.errors.length > 0) {
              setError('Error parsing CSV data');
              setStatus('error');
              return;
            }

            const parsedData = results.data.map((row: any) => ({
              ...row,
              time_period: Number(row.time_period),
              agent_toxicity: Number(row.agent_toxicity)
            }));

            // Get unique platforms
            const uniquePlatforms = _.uniq(parsedData.map((row: any)  => row.platform_name)).filter(Boolean);
            setPlatforms(uniquePlatforms as never[]);

            // Get unique timeperiods
            const timeperiods = _.uniq(parsedData.map((row: any) => row.time_period)).sort((a,b) => a - b);
            
            // Process data for each timeperiod
            const averages = timeperiods.map(period => {
              const periodData = parsedData.filter((row: any) => row.time_period === period);
              const platformGroups = _.groupBy(periodData, 'platform_name');
              
              const dataPoint = {
                time_period: period
              };
              
              uniquePlatforms.forEach(platform => {
                const platformData = platformGroups[platform] || [];
                const activeAgents = platformData.filter((row: any) => 
                  row.active === "True" || row.active === true
                );
                
                const avgToxicity = activeAgents.length > 0 
                  ? _.meanBy(activeAgents, 'agent_toxicity')
                  : 0;
                  
                dataPoint[platform] = avgToxicity;
              });
              
              return dataPoint;
            });
            
            setData(averages as never[]);
            setStatus('success');
          }
        });
      } catch (error) {
        setError('Error loading data file');
        setStatus('error');
      }
    };

    loadData();
  }, [selectedRun]);

  // Prepare data for Plotly
  const plotData: Data[] = platforms.map((platform, index) => ({
    x: data.map(d => d.time_period),
    y: data.map(d => d[platform]),
    type: 'scatter',
    mode: 'lines',
    name: platform,
    line: {
      color: colors[index % colors.length],
      width: 2
    }
  }));

  const layout = {
    title: {
      text: 'Average Toxicity by Platform',
      font: {
        family: 'Inter, system-ui, sans-serif',
        size: 24,
        color: '#1f2937'
      }
    },
    yaxis: {
      title: {
        text: 'Average Toxicity',
        font: {
          family: 'Inter, system-ui, sans-serif',
          size: 14,
          color: '#4b5563'
        }
      },
      range: [0, 1],
      zeroline: true,
      zerolinecolor: '#e5e7eb',
      gridcolor: '#f3f4f6',
      tickfont: {
        family: 'Inter, system-ui, sans-serif',
        size: 12,
        color: '#6b7280'
      }
    },
    xaxis: {
      title: {
        text: 'Time Period',
        font: {
          family: 'Inter, system-ui, sans-serif',
          size: 14,
          color: '#4b5563'
        }
      },
      tickfont: {
        family: 'Inter, system-ui, sans-serif',
        size: 12,
        color: '#6b7280'
      }
    },
    plot_bgcolor: '#ffffff',
    paper_bgcolor: '#ffffff',
    autosize: true,
    margin: {
      l: 50,
      r: 30,
      t: 50,
      b: 50
    }
  };

  return (
    <Card className="w-full max-w-5xl">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl font-bold tracking-tight">Toxicity Trend Analysis</CardTitle>
        <div className="flex items-center space-x-4">
          <select 
            value={selectedRun} 
            onChange={(e) => setSelectedRun(e.target.value)}
            className="px-3 py-2 rounded-md border border-gray-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {['run1', 'run2', 'run3', 'run4', 'run5', 'run6', 'run7', 'run8'].map(run => (
              <option key={run} value={run}>{run}</option>
            ))}
          </select>
        </div>
      </CardHeader>
      
      <CardContent>
        {status === 'loading' && (
          <div className="flex items-center justify-center h-96">
            <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
          </div>
        )}
        
        {status === 'error' && (
          <div className="flex items-center justify-center h-96 text-red-500">
            <AlertCircle className="w-6 h-6 mr-2" />
            <span>{error}</span>
          </div>
        )}
        
        {status === 'success' && (
          <div className="mt-4 w-full">
            <Plot
              data={plotData}
              layout={layout}
              config={{
                displayModeBar: false,
                responsive: true
              }}
              style={{ width: '100%', height: '450px' }}
              className="w-full"
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ToxicityAnalysis;