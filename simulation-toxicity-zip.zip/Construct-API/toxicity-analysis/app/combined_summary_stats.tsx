import React, { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import Papa from 'papaparse';
import _ from 'lodash';
import { AlertCircle, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface ToxicityDataRow {
  platform: number;
  timestamp: number;
  author: string;
  author_toxicity: number;
  toxicity: number | null;
  knowledge: number;
  platform_model_name: string;
  platform_network_name: string;
  platform_interval_time_duration: number;
  platform_maximum_post_inactivity: number;
  platform_toxicity_threshold: number;
  platform_full_ban: boolean;
  platform_partial_ban: boolean;
  platform_warning: boolean;
  platform_remove_content: boolean;
  platform_network_ban_threshold: number;
  platform_network_warning_threshold: number;
  platform_moderation_miss_probability: number;
  platform_partial_ban_length: number;
}

interface RunStats {
  runId: string;
  avgToxicity: number;
  medianToxicity: number;
  percentWithToxicity: number;
  totalPosts: number;
  postsWithToxicity: number;
}

const Plot = dynamic(() => import('react-plotly.js'), {
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center h-96">
      <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
    </div>
  )
});

const CombinedSummaryStats = () => {
  const [data, setData] = useState<RunStats[]>([]);
  const [selectedRuns, setSelectedRuns] = useState<string[]>(['run1', 'run2', 'run3']);
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [error, setError] = useState<string | null>(null);

  const colors = {
    avgToxicity: '#3b82f6',      // Blue
    percentWithToxicity: '#22c55e', // Green
    totalPosts: '#f97316'         // Orange
  };

  const calculateStats = (data: ToxicityDataRow[]): RunStats => {
    const toxicityValues = data
      .filter(row => row.toxicity !== null)
      .map(row => row.toxicity as number);

    const totalPosts = data.length;
    const postsWithToxicity = toxicityValues.length;
    console.log(toxicityValues);
    console.log(data)

    return {
      runId: '',  // Will be set later
      avgToxicity: _.mean(toxicityValues) || 0,
      medianToxicity: _.sortBy(toxicityValues)[Math.floor(toxicityValues.length / 2)] || 0,
      percentWithToxicity: (postsWithToxicity / totalPosts) * 100,
      totalPosts,
      postsWithToxicity
    };
  };

  useEffect(() => {
    const loadData = async () => {
      setStatus('loading');
      try {
        const runData = await Promise.all(
          selectedRuns.map(async (run) => {
            const response = await fetch(`processed_data/${run}/all_events.csv`);
            const csvText = await response.text();
            
            return new Promise<RunStats>((resolve, reject) => {
              Papa.parse(csvText, {
                header: true,
                dynamicTyping: true,
                skipEmptyLines: true,
                complete: (results) => {
                  if (results.errors.length > 0) {
                    reject(new Error('Error parsing CSV data'));
                    return;
                  }
                  const stats = calculateStats(results.data as ToxicityDataRow[]);
                  stats.runId = run;
                  resolve(stats);
                },
                error: (error) => reject(error)
              });
            });
          })
        );

        setData(runData);
        setStatus('success');
      } catch (error) {
        setError('Error loading data files');
        setStatus('error');
      }
    };

    loadData();
  }, [selectedRuns]);

  const createBarPlot = (metric: keyof RunStats, title: string, color: string) => {
    return (
      <Plot
        data={[{
          type: 'bar',
          x: data.map(d => d.runId),
          y: data.map(d => d[metric]),
          marker: { color },
          name: title
        }]}
        layout={{
          title: {
            text: title,
            font: {
              family: 'Inter, system-ui, sans-serif',
              size: 16,
              color: '#1f2937'
            }
          },
          height: 300,
          width: undefined,
          margin: { l: 50, r: 30, t: 40, b: 40 },
          plot_bgcolor: '#ffffff',
          paper_bgcolor: '#ffffff',
          xaxis: {
            tickfont: { size: 12, color: '#6b7280' }
          },
          yaxis: {
            tickfont: { size: 12, color: '#6b7280' }
          },
          showlegend: false
        }}
        config={{
          displayModeBar: false,
          responsive: true
        }}
        style={{ width: '100%' }}
        className="w-full"
      />
    );
  };

  return (
    <Card className="w-full max-w-5xl">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl font-bold tracking-tight">Multi-Run Toxicity Analysis</CardTitle>
        <div className="flex flex-wrap items-center gap-2">
          {['run1', 'run2', 'run3', 'run4', 'run5', 'run6', 'run7', 'run8'].map(run => (
            <label key={run} className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={selectedRuns.includes(run)}
                onChange={(e) => {
                  if (e.target.checked) {
                    setSelectedRuns([...selectedRuns, run]);
                  } else {
                    setSelectedRuns(selectedRuns.filter(r => r !== run));
                  }
                }}
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm">{run}</span>
            </label>
          ))}
        </div>
      </CardHeader>
      
      <CardContent>
        {status === 'loading' && (
          <div className="flex items-center justify-center h-96">
            <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
          </div>
        )}
        
        {status === 'error' && (
          <div className="flex items-center justify-center h-96 text-red-500">
            <AlertCircle className="w-6 h-6 mr-2" />
            <span>{error}</span>
          </div>
        )}
        
        {status === 'success' && (
          <div className="grid gap-6">
            {createBarPlot('avgToxicity', 'Average Toxicity', colors.avgToxicity)}
            {createBarPlot('percentWithToxicity', 'Percent Posts with Toxicity', colors.percentWithToxicity)}
            {createBarPlot('totalPosts', 'Total Posts', colors.totalPosts)}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CombinedSummaryStats;