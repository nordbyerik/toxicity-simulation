import React, { useState, useEffect } from 'react';
import dynamic from 'next/dynamic';
import Papa from 'papaparse';
import _ from 'lodash';
import { AlertCircle, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Layout } from 'plotly.js';

const Plot = dynamic(() => import('react-plotly.js'), {
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center h-96">
      <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
    </div>
  )
});

const ToxicityViolinPlot = () => {
  const [data, setData] = useState([]);
  const [selectedRun, setSelectedRun] = useState('run8');
  const [status, setStatus] = useState('loading');
  const [error, setError] = useState<string | null>(null);

  // Modern, minimal color palette
  const colors = [
    '#3b82f6', // Primary blue
    '#22c55e', // Fresh green
    '#a855f7', // Soft purple
    '#f97316', // Subtle orange
  ];

  useEffect(() => {
    const loadData = async () => {
      setStatus('loading');
      try {
        const response = await fetch(`processed_data/${selectedRun}/platform_activity.csv`);
        const csvText = await response.text();
        
        Papa.parse(csvText, {
          header: true,
          dynamicTyping: true,
          skipEmptyLines: true,
          complete: (results) => {
            if (results.errors.length > 0) {
              setError('Error parsing CSV data');
              setStatus('error');
              return;
            }

            const uniquePlatforms = _.uniq(results.data.map((row: any) => row.platform_name)).filter(Boolean);
            const maxTimePeriod = _.max(results.data.map((row: any) => row.time_period));
            const lastTimeData = results.data.filter((row: any) => row.time_period === maxTimePeriod);

            const violinData = uniquePlatforms.map((platform, index) => {
              const platformData = lastTimeData.filter((row: any) => 
                row.platform_name === platform && 
                row.active === "True" &&
                row.agent_toxicity !== null
              );
              
              return {
                type: 'box',
                x: Array(platformData.length).fill(platform),
                y: platformData.map((d: any) => d.agent_toxicity),
                name: platform,
                boxpoints: 'outliers',
                jitter: 0.3,
                pointpos: 0,
                line: {
                  color: colors[index % colors.length],
                  width: 2
                },
                fillcolor: 'rgba(255,255,255,0.9)',
                marker: {
                  color: colors[index % colors.length],
                  opacity: 0.7,
                  size: 4
                },
                whiskerwidth: 0.5,
                boxmean: 'sd'
              };
            });
            
            setData(violinData as never[]);
            setStatus('success');
          }
        });
      } catch (error) {
        setError('Error loading data file');
        setStatus('error');
      }
    };

    loadData();
  }, [selectedRun]);

  const layout: Partial<Layout> = {
    title: {
      text: 'Agent Toxicity Distribution by Platform',
      font: {
        family: 'Inter, system-ui, sans-serif',
        size: 24,
        color: '#1f2937'
      }
    },
    yaxis: {
      title: {
        text: 'Agent Toxicity',
        font: {
          family: 'Inter, system-ui, sans-serif',
          size: 14,
          color: '#4b5563'
        }
      },
      range: [-0.25, 1.25],
      zeroline: true,
      zerolinecolor: '#e5e7eb',
      gridcolor: '#f3f4f6',
      tickfont: {
        family: 'Inter, system-ui, sans-serif',
        size: 12,
        color: '#6b7280'
      }
    },
    xaxis: {
      title: {
        text: 'Platform',
        font: {
          family: 'Inter, system-ui, sans-serif',
          size: 14,
          color: '#4b5563'
        }
      },
      tickfont: {
        family: 'Inter, system-ui, sans-serif',
        size: 12,
        color: '#6b7280'
      }
    },
    plot_bgcolor: '#ffffff',
    paper_bgcolor: '#ffffff',
    autosize: true,
    margin: {
      l: 50,
      r: 30,
      t: 50,
      b: 50
    },
    boxmode: 'group' as const,
  } as const;

  return (
    <Card className="w-full max-w-5xl">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl font-bold tracking-tight">Toxicity Distribution Analysis</CardTitle>
        <div className="flex items-center space-x-4">
          <select 
            value={selectedRun} 
            onChange={(e) => setSelectedRun(e.target.value)}
            className="px-3 py-2 rounded-md border border-gray-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {['run1', 'run2', 'run3', 'run4', 'run5', 'run6', 'run7', 'run8'].map(run => (
              <option key={run} value={run}>{run}</option>
            ))}
          </select>
        </div>
      </CardHeader>
      
      <CardContent>
        {status === 'loading' && (
          <div className="flex items-center justify-center h-96">
            <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
          </div>
        )}
        
        {status === 'error' && (
          <div className="flex items-center justify-center h-96 text-red-500">
            <AlertCircle className="w-6 h-6 mr-2" />
            <span>{error}</span>
          </div>
        )}
        
        {status === 'success' && (
          <div className="mt-4 w-full">
            <Plot
              data={data}
              layout={layout}
              config={{
                displayModeBar: false,
                responsive: true
              }}
              style={{ width: '100%', height: '450px' }}
              className="w-full"
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ToxicityViolinPlot;