import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { BarChart, Bar } from 'recharts';
import { useState, useEffect } from 'react';
import ToxicityAnalysis from './toxicity_analysis';
import ComparativeAnalysis from './comparative_analysis';
import UserMigration from './user_migration';
import PlatformAnalysis from './platform_analysis';
import ToxicityDistribution from './toxicity_distribution';
import CombinedSummaryStats from './combined_summary_stats';
// Helper functions for generating sample data
const generateToxicityData = () => {
    return Array.from({ length: 12 }, (_, i) => ({
      period: `Period ${i + 1}`,
      highMod: 100 - Math.exp(i / 4),
      lowMod: 100 - Math.exp(i / 8)
    }));
  };
  
  const generatePlatformData = () => {
    return [
      { platform: 'Platform A', toxicity: 45, engagement: 80 },
      { platform: 'Platform B', toxicity: 65, engagement: 60 },
      { platform: 'Platform C', toxicity: 30, engagement: 90 },
      { platform: 'Platform D', toxicity: 75, engagement: 40 }
    ];
  };
  
  const generateMigrationData = () => {
    return Array.from({ length: 6 }, (_, i) => ({
      month: `Month ${i + 1}`,
      migrations: Math.floor(Math.random() * 1000)
    }));
  };

export default function Results() {
      // State management for different sections and visualizations
  const [activeSection, setActiveSection] = useState('abstract');
  const [data, setData] = useState({
    toxicityData: [],
    platformData: [],
    migrationData: []
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading data
    setTimeout(() => {
      setData({
        toxicityData: generateToxicityData() as never[],
        platformData: generatePlatformData() as never[],
        migrationData: generateMigrationData() as never[]
      });
      setIsLoading(false);
    }, 500);
  }, []);

  return (
    <div>
      <h2 className="text-2xl font-serif mb-6">Results</h2>

            <div className="space-y-8">
              {/* Toxicity Evolution */}
              <CombinedSummaryStats />
              <ToxicityAnalysis />
              <ToxicityDistribution />
              <ComparativeAnalysis />
              <UserMigration />
              <PlatformAnalysis />
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h3 className="text-xl font-semibold mb-4">Temporal Evolution of Network Toxicity</h3>
                <p className="text-gray-600 mb-6">
                  Figure 1 shows the relationship between moderation strength and toxicity levels over time.
                </p>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={data.toxicityData} margin={{ top: 10, right: 30, left: 0, bottom: 20 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
                      <XAxis 
                        dataKey="period" 
                        label={{ value: 'Time Period', position: 'bottom' }}
                      />
                      <YAxis 
                        label={{ value: 'Toxicity Score', angle: -90, position: 'insideLeft' }}
                      />
                      <Tooltip />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="highMod" 
                        name="High Moderation"
                        stroke="#dc2626" 
                        strokeWidth={2}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="lowMod" 
                        name="Low Moderation"
                        stroke="#2563eb" 
                        strokeWidth={2}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Platform Comparison */}
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h3 className="text-xl font-semibold mb-4">Cross-Platform Analysis</h3>
                <p className="text-gray-600 mb-6">
                  Figure 2 compares toxicity levels and user engagement across platforms with different 
                  moderation policies.
                </p>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={data.platformData} margin={{ top: 10, right: 30, left: 0, bottom: 20 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="platform" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="toxicity" name="Toxicity Score" fill="#dc2626" />
                      <Bar dataKey="engagement" name="User Engagement" fill="#2563eb" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Key Findings Summary */}
              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-xl font-semibold mb-4">Key Findings</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">1.</span>
                    <span>Strict moderation reduced platform-specific toxicity by 60%</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">2.</span>
                    <span>User migration increased toxicity on alternative platforms by 45%</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 font-bold mr-2">3.</span>
                    <span>Network effects amplified the impact of moderation strategies</span>
                  </li>
                </ul>
              </div>
            </div>
    </div>
  )
}