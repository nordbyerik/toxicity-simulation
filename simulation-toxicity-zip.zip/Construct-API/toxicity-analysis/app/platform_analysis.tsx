import React, { useState, useEffect } from 'react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Papa from 'papaparse';
import _ from 'lodash';

const PlatformAnalysis = () => {
  const [toxicityData, setToxicityData] = useState([]);
  const [userCounts, setUserCounts] = useState([]);
  const [migrationData, setMigrationData] = useState([]);

  useEffect(() => {
    const loadData = async () => {
      try {
        // Load platform activity data
        const activityResponse = await fetch('/processed_data/run8/platform_activity.csv');
        const activityText = await activityResponse.text();
        const activityData = Papa.parse(activityText, {
          header: true,
          skipEmptyLines: true,
          dynamicTyping: true
        });

        // Process activity data for user counts
        const processedCounts = _(activityData.data)
          .filter((row: any) => row.active === true)
          .groupBy('time_period')
          .map((group, period) => ({
            period: parseInt(period),
            ..._(group)
              .groupBy('platform_name')
              .mapValues(v => v.length)
              .value()
          }))
          .sortBy('period')
          .value();

        setUserCounts(processedCounts as never[]);

        // Load platform event data for toxicity analysis
        const events3Response = await fetch('/processed_data/run8/platform_3_events.csv');
        const events2Response = await fetch('/processed_data/run8/platform_2_events.csv');
        const events1Response = await fetch('/processed_data/run8/platform_1_events.csv');

        const events3Text = await events3Response.text();
        const events2Text = await events2Response.text();
        const events1Text = await events1Response.text();

        const events3Data = Papa.parse(events3Text, { header: true, skipEmptyLines: true, dynamicTyping: true }).data;
        const events2Data = Papa.parse(events2Text, { header: true, skipEmptyLines: true, dynamicTyping: true }).data;
        const events1Data = Papa.parse(events1Text, { header: true, skipEmptyLines: true, dynamicTyping: true }).data;

        // Process toxicity data
        const combinedEvents = [...events1Data, ...events2Data, ...events3Data];
        const toxicityTrends = _(combinedEvents)
          .groupBy((row: any) => `${row.platform}-${Math.floor(row.timestamp / 10)}`)
          .map((group, key) => {
            const [platform, timeBlock] = key.split('-');
            const avgToxicity = _(group)
              .filter((row: any) => row.toxicity !== null && !isNaN(row.toxicity))
              .meanBy('toxicity');
            
            return {
              platform: `Model ${platform}`,
              timeBlock: parseInt(timeBlock) * 10,
              avgToxicity: avgToxicity || 0
            };
          })
          .filter(item => !isNaN(item.avgToxicity))
          .value();

        setToxicityData(toxicityTrends as never[]);

      } catch (error) {
        console.error('Error loading data:', error);
      }
    };

    loadData();
  }, []);

  return (
    <div className="w-full space-y-8">
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-4">Toxicity Trends Across Platforms</h2>
        <div className="h-96">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={toxicityData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="timeBlock" 
                label={{ value: 'Time Period', position: 'bottom' }}
              />
              <YAxis 
                label={{ value: 'Average Toxicity', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="avgToxicity" name="Model 1" stroke="#8884d8" dot={false} />
              <Line type="monotone" dataKey="avgToxicity" name="Model 2" stroke="#82ca9d" dot={false} />
              <Line type="monotone" dataKey="avgToxicity" name="Model 3" stroke="#ffc658" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-4">User Distribution Over Time</h2>
        <div className="h-96">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={userCounts}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="period"
                label={{ value: 'Time Period', position: 'bottom' }}
              />
              <YAxis 
                label={{ value: 'Number of Users', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip />
              <Legend />
              <Area 
                type="monotone" 
                dataKey="Toxic Model 1" 
                stackId="1"
                stroke="#8884d8" 
                fill="#8884d8" 
              />
              <Area 
                type="monotone" 
                dataKey="Toxic Model 2" 
                stackId="1"
                stroke="#82ca9d" 
                fill="#82ca9d" 
              />
              <Area 
                type="monotone" 
                dataKey="Toxic Model 3" 
                stackId="1"
                stroke="#ffc658" 
                fill="#ffc658" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default PlatformAnalysis;