import React, { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Papa from 'papaparse';
import _ from 'lodash';

// Generate colors dynamically based on index
const getColor = (index) => {
  const colors = [
    '#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#00C49F',
    '#FFBB28', '#FF8042', '#0088FE', '#00C49F', '#FFBB28'
  ];
  return colors[index % colors.length];
};

const UserMigrationViz = () => {
  const [data, setData] = useState([]);
  const [platforms, setPlatforms] = useState([]);
  const [selectedRun, setSelectedRun] = useState('run8');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      try {
        const response = await fetch(`/processed_data/${selectedRun}/platform_activity.csv`);
        const csvText = await response.text();
        Papa.parse(csvText, {
          header: true,
          dynamicTyping: true,
          complete: (results) => {
            // Get unique platforms
            const uniquePlatforms = _.uniq(results.data.map((row: any) => row.platform_name));
            setPlatforms(uniquePlatforms as never[]);

            // Get unique timeperiods
            const timeperiods = _.uniq(results.data.map((row: any) => row.time_period)).sort((a,b) => a - b);
            
            // Process data for each timeperiod
            const averages = timeperiods.map(period => {
                const periodData = results.data.filter((row: any) => row.time_period === period);
                const platformGroups = _.groupBy(periodData, 'platform_name');
                
                // Create data point with dynamic platform fields
                const dataPoint = {
                  time_period: period
                };
                
                // Add average toxicity for each platform
                uniquePlatforms.forEach(platform => {
                  const platformData = platformGroups[platform] || [];
                  const activeAgents = platformData.filter((row: any) => 
                    row.active === "True" || row.active === true
                  );
                  
                  // Calculate average toxicity for active agents
                  const avgToxicity = activeAgents.length > 0 
                    ? _.meanBy(activeAgents, 'agent_toxicity')
                    : 0;
                    
                  dataPoint[platform] = avgToxicity;
                });
                
                return dataPoint;
              });
            
            console.log(averages);
            setData(averages as never[]);
            setIsLoading(false);
          }
        });
      } catch (error) {
        console.error('Error loading data:', error);
        setIsLoading(false);
      }
    };

    loadData();
  }, [selectedRun]);

  const handleRunChange = (event) => {
    setSelectedRun(event.target.value);
  };

  if (isLoading) {
    return <div className="flex items-center justify-center h-96">Loading...</div>;
  }

  return (
    <div className="w-full max-w-6xl mx-auto p-4">
      <div className="mb-4">
        <label className="mr-2">Select Run:</label>
        <select 
          value={selectedRun} 
          onChange={handleRunChange}
          className="border rounded p-1"
        >
          {['run1', 'run2', 'run3', 'run4', 'run5', 'run6', 'run7', 'run8'].map(run => (
            <option key={run} value={run}>{run}</option>
          ))}
        </select>
      </div>

      <div className="h-96 w-full">
        <ResponsiveContainer>
          <AreaChart
            data={data}
            margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="time_period" 
              label={{ value: 'Time Period', position: 'bottom' }}
            />
            <YAxis 
              label={{ value: 'Number of Active Users', angle: -90, position: 'insideLeft' }}
            />
            <Tooltip />
            <Legend />
            {platforms.map((platform, index) => (
              <Area
                key={platform}
                type="monotone"
                dataKey={platform}
                stackId="1"
                stroke={getColor(index)}
                fill={getColor(index)}
              />
            ))}
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default UserMigrationViz;